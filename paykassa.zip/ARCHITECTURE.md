# PayKassa Architecture Map

```text
WooCommerce Checkout
       |
 Gateway / Blocks adapter
       |
 OrderPaymentService ----> InvoiceLockStore
       |                         |
       v                         v
 PayKassa SCI ------------> immutable PaymentSnapshot

PayKassa invoice POST                    PayKassa transaction POST
       |                                           |
 WebhookController                    TransactionNotificationController
       |                                           |
 sci_confirm_order                    sci_confirm_transaction_notification
       |                                           |
 PaymentEvidence                     TransactionNotificationEvidence
       |                                           |
       +-----------> WebhookProcessor <------------+
                              |
                 WebhookEventStore + settlement mutex
                              |
                 WooCommerce payment_complete()

PayKassa browser success/failure redirects
       |
 BrowserReturnController + ownership verification
       |
 native WooCommerce thank-you/retry URL
 (never settlement)
```

## Trust hierarchy

1. Stored immutable invoice snapshot.
2. Server-to-server verified PayKassa evidence.
3. WooCommerce authoritative order state.
4. Durable event/invoice reservations.

Raw browser/callback fields are not trusted evidence.

Transaction notification evidence deliberately has no payment-link hash. It is never cast into invoice evidence and no stored hash is substituted as if PayKassa had verified it. Its stricter match policy requires Live mode and an unambiguous active snapshot match across verified order ID, shop ID, amount, payment currency and provider system. Retired or ambiguous candidates are durable manual-review outcomes.

## Layer ownership

- `Gateway/`: Woo checkout boundary.
- `Blocks/`: Woo Checkout Blocks boundary only.
- `PayKassa/`: provider adapters/DTOs.
- `Order/`: payment snapshot, state, invoice reservation, settlement-facing business rules.
- `Webhook/`: external callback verification orchestration and durable deduplication.
- `Reconciliation/`: bounded recovery/diagnostic work.
- `Infrastructure/`: installation/schema/logging.
- `Admin/`: diagnostics/order display, never payment truth.

Payment business rules must not migrate into templates/admin JavaScript.

`MerchantEndpointUrls` is the only source of endpoint names and Merchant URL generation. Server callbacks and browser returns have independently validated optional public bases, each defaulting to `home_url('/')`. The browser-return base must be the same public origin where checkout occurred so browser ownership cookies remain available; it may legitimately be a tunnel or the canonical storefront. `BrowserReturnAccess` stores a bounded guest-session grant containing only an HMAC of the WooCommerce order key. Registered orders require the owning logged-in user, except administrators with `manage_woocommerce`.

See [the merchant endpoint decision](docs/architecture/merchant-endpoints-decision.md).
