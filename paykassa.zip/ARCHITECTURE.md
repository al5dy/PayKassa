# PayKassa Architecture Map

```text
WooCommerce Checkout
       |
 Gateway / Blocks adapter
       |
 OrderPaymentService ----> InvoiceLockStore
       |                         |
       v                         v
 PayKassa SCI ------------> immutable PaymentSnapshot

PayKassa callback
       |
 WebhookController
       |
 provider server-to-server verification
       |
 PaymentEvidence
       |
 WebhookProcessor
       |
 WebhookEventStore durable reservation
       |
 WooCommerce payment_complete()
```

## Trust hierarchy

1. Stored immutable invoice snapshot.
2. Server-to-server verified PayKassa evidence.
3. WooCommerce authoritative order state.
4. Durable event/invoice reservations.

Raw browser/callback fields are not trusted evidence.

## Layer ownership

- `Gateway/`: Woo checkout boundary.
- `Blocks/`: Woo Checkout Blocks boundary only.
- `PayKassa/`: provider adapters/DTOs.
- `Order/`: payment snapshot, state, invoice reservation, settlement-facing business rules.
- `Webhook/`: external callback verification orchestration and durable deduplication.
- `Reconciliation/`: bounded recovery/diagnostic work.
- `Infrastructure/`: installation/schema/logging.
- `Admin/`: diagnostics/order display, never payment truth.

Payment business rules must not migrate into templates/admin JavaScript.
