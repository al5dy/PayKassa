# Codex Task — Bring PayKassa 2.0 Working Tree to Production-Ready State

Read root `AGENTS.md` and every routed handbook chapter before editing.

## Protected README rule

Do not modify `readme.txt`, root `README.md` or `CHANGELOG.md` in this task unless the user separately gives explicit authorization for exact sections/metadata.

## Immediate known blockers from supplied snapshot

1. Restore/reconcile `src/Webhook/WebhookProcessor.php`; it is deleted from working source while runtime code references it and stale `dist` still contains a copy.
2. Fix `paykassa_invoice_locks` schema/runtime mismatch: `InvoiceLockStore` increments `attempts`, but table schema currently lacks the column.
3. Bump schema through a versioned, retry-safe migration rather than mutating history silently.
4. Strengthen `schema_is_valid()` to validate every lock/event table column/index needed by runtime SQL.
5. Add integration coverage for expired invoice lease reclaim and schema upgrade.
6. Automate real WooCommerce integration smoke in CI; existing WP-CLI scripts cannot remain release-critical but unexecuted.
7. Add source-to-package runtime parity verification so final ZIP cannot contain stale/missing critical classes.

## Payment verification matrix

Automate tests for:

- valid provider-verified matching callback;
- duplicate callback;
- two concurrent identical callbacks;
- DB reservation failure;
- worker crash/lease expiry then retry;
- wrong order;
- non-PayKassa order;
- wrong merchant context;
- wrong environment;
- wrong invoice/link hash;
- exact amount mismatch;
- currency mismatch;
- system/network mismatch;
- already-paid order;
- cancelled order with late valid payment;
- malformed/oversized callback;
- provider verification error/timeout/malformed response;
- event finalization failure after order settlement without duplicate fulfilment on retry.

## Invoice creation matrix

Test:

- first creation;
- immediate retry reuses active invoice;
- concurrent creation produces one provider create call;
- expired lease reclaim;
- lock-table DB failure;
- unsafe redirect;
- provider explicit failure;
- provider ambiguous timeout does not issue blind second invoice;
- snapshot saved but lock-finalization failed remains recoverable without duplicate invoice.

## WooCommerce compatibility matrix

Test current declared minimum and latest stable release targets, including:

- HPOS;
- Classic Checkout;
- Checkout Blocks;
- guest checkout;
- order-pay/retry;
- settings migration from 1.0.2;
- secret blank-save preservation;
- stock reduced once;
- no duplicate fulfilment hooks.

As of 2026-09-10 latest stable public versions are WordPress 7.1 and WooCommerce 11.1.x; verify current versions again at execution/release time.

## Quality improvements

- Keep all project PHP strictly typed.
- Raise PHPStan from level 5 toward max practical strictness without broad ignores.
- Strengthen WordPress/WooCommerce coding-standard checks appropriately.
- Add property/fuzz cases for decimal/provider/token/redirect parsing.
- Add mutation tests for settlement-critical conditions where practical.
- Add fault-injection/concurrency suite.
- Add final ZIP install/activate/callback smoke.

## Definition of Done

Do not complete while any known blocker remains, integration smoke is unexecuted, source/package parity fails, payment idempotency is unproven, or protected README files changed without explicit authorization.

Final report must list exact commands and pass/fail results. Never claim an unexecuted test passed.
