# Installing the PayKassa Engineering Handbook

Copy into repository preserving paths:

- `AGENTS.md`
- `ARCHITECTURE.md`
- `docs/engineering/`
- `tools/verify_paykassa_handbook.py`
- `tools/verify_readme_guard.py`
- optionally `PAYKASSA_CODEX_PRODUCTION_HARDENING_TASK.md`

Do not replace or modify existing `readme.txt`, root `README.md` or `CHANGELOG.md` unless explicitly authorized.

Run:

```bash
python3 tools/verify_paykassa_handbook.py
python3 tools/verify_readme_guard.py
```
