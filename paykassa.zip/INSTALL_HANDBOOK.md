# Installing the PayKassa Engineering Handbook

Copy into repository preserving paths:

- `AGENTS.md`
- `ARCHITECTURE.md`
- `docs/engineering/`
- `tools/verify_paykassa_handbook.py`
- `tools/verify_readme_guard.py`
- optionally `PAYKASSA_CODEX_PRODUCTION_HARDENING_TASK.md`

Do not replace or modify existing `readme.txt`, root `README.md` or `CHANGELOG.md` unless explicitly authorized.

Run:

```bash
python3 tools/verify_paykassa_handbook.py
python3 tools/verify_readme_guard.py
```

## PayKassa Merchant URL installation

After configuring the PayKassa gateway, open **WooCommerce → PayKassa health → PayKassa Merchant URLs**. Copy each generated value into the identically named field in the PayKassa Merchant dashboard:

| PayKassa field | URL suffix |
|---|---|
| URL of Invoice Payment Notifications | `/?wc-api=wc_gateway_paykassa` |
| URL of successful payment | `/?wc-api=wc_gateway_paykassa_return` |
| URL malfunction when paying | `/?wc-api=wc_gateway_paykassa_cancel` |
| URL of Cryptocurrency Transaction Processor | `/?wc-api=wc_gateway_paykassa_transaction` |

The callback and browser-return bases default independently to the WordPress home URL, including a WordPress subdirectory when present. **External PayKassa callback base URL (optional)** applies only to Invoice Payment Notification and Cryptocurrency Transaction Processor. **External PayKassa browser return base URL (optional)** applies only to successful payment and malfunction returns. Set the browser-return base to the public origin where customers actually perform checkout; this may be the same tunnel as the callbacks or the canonical storefront. Both overrides must be absolute URLs without credentials, query strings or fragments, and both require HTTPS in Live mode. When either override is removed, only its own URL pair returns to the WordPress home URL.

The success and malfunction fields are browser redirects. They never verify payment, call `payment_complete()`, cancel an order or retire an invoice. Guest returns work only in the WooCommerce session that created/reused the PayKassa invoice; a lost session falls back without disclosing the order key. Registered customers must own the order.

The invoice and transaction processor fields are separate POST-only server callbacks. Both authenticate by sending `private_hash` back to PayKassa SCI; source IP is not authentication. Ensure firewalls, reverse proxies and tunnels allow PayKassa notification servers to reach both public URLs. A GET response of `405 Method Not Allowed` on either callback is expected.

Optional minimum rules are merchant policy, not provider limits. If used, key every rule by exact network and currency (for example `Ethereum_ERC20:USDT=5` and `TRON_TRC20:USDT=2`). Defaults are empty, and no value is inferred from observed small-payment behavior.
