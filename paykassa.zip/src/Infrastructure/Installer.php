<?php

declare(strict_types=1);

namespace Al5dy\PayKassaWoo\Infrastructure;

final class Installer
{
    public const SCHEMA_VERSION = '1';
    public const OPTION = 'paykassa_schema_version';

    public static function activate(): void
    {
        self::migrate();
    }

    public static function migrate(): void
    {
        global $wpdb;
        $table           = $wpdb->prefix . 'paykassa_events';
        $charset_collate = $wpdb->get_charset_collate();
        $sql             = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			provider_transaction_id varchar(191) NOT NULL,
			hash_fingerprint char(64) NOT NULL,
			order_id bigint(20) unsigned NOT NULL,
			event_type varchar(32) NOT NULL,
			status varchar(32) NOT NULL,
			created_at datetime NOT NULL,
			processed_at datetime NULL,
			error_code varchar(64) NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY provider_transaction (provider_transaction_id),
			KEY order_status (order_id,status),
			KEY created_at (created_at)
		) {$charset_collate};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        update_option(self::OPTION, self::SCHEMA_VERSION, false);
    }
}
