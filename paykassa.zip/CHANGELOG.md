# Changelog

## 2.0.0

See the WordPress.org readme for the full release notes and retained 1.x history.
