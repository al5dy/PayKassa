# AGENTS.md — PayKassa for WooCommerce

## Project mission

This repository contains `PayKassa for WooCommerce`.

Treat it as payment infrastructure, not as a generic WordPress plugin.

Correctness, payment integrity, security, idempotency, WooCommerce compatibility and maintainability have priority over code volume, clever abstractions or visual polish.

For help use files in plugin root:
1. API.md
2. PaykassaAPI.md
3. PaykassaSCI.md

---

## Non-negotiable compatibility

Preserve:

- WordPress.org slug: `paykassa`
- text domain: `paykassa`
- WooCommerce gateway ID: `paykassa`
- existing 1.0.2 gateway settings and credentials
- legacy callback: `?wc-api=wc_gateway_paykassa`
- old changelog history

Never destroy existing merchant settings during upgrade.

All migrations must be versioned, idempotent and retry-safe.

---

## Runtime baseline

Target:

- PHP 8.1+
- WordPress 6.6+
- WooCommerce 8.5+
- latest stable WordPress/WooCommerce must always be tested before release

Use modern PHP where it improves correctness, but remain within the declared minimum.

---

## PHP rules

Use:

```php
declare(strict_types=1);
```

for new project-owned PHP files where compatible with WordPress loading conventions.

Prefer explicit parameter and return types.

Prefer:
- `int`
- `string`
- `bool`
- `array`
- nullable types
- DTO/value objects
- enums only when the PHP baseline and interoperability make them appropriate

Avoid untyped public mutable state.

Do not use `mixed` when a meaningful type can be expressed.

Do not create abstractions that have no current architectural value.

---

## Namespace

Project-owned classes:

`Al5dy\PayKassaWoo\...`

Do not use a top-level `Paykassa` namespace because the official provider wrapper may use it.

No new global classes unless required by WordPress/WooCommerce integration boundaries.

---

## Architecture

Separate:

- WordPress bootstrap
- WooCommerce gateway adapter
- Checkout Blocks integration
- PayKassa provider client
- webhook verification
- payment processing
- order state
- reconciliation
- admin UI
- diagnostics
- persistence
- logging

Hooks should call services; hooks must not contain payment business logic.

No god classes.

No service locator hidden globals.

Dependency direction should point toward domain/application logic, not from domain logic into admin/UI code.

---

## WooCommerce order rules

For orders:

ALWAYS use WooCommerce APIs.

Preferred:

```php
$order = wc_get_order($orderId);
$order->get_id();
$order->get_order_number();
$order->get_total();
$order->get_currency();
$order->get_meta();
$order->update_meta_data();
$order->save();
```

Never use direct order access via:

- `get_post()`
- `get_post_meta()`
- `update_post_meta()`
- direct `wp_posts`
- direct `wp_postmeta`

unless a specific non-order WordPress object requires it.

`get_order_number()` is display data.

It is NEVER the internal primary key.

Provider correlation must use the WooCommerce internal order ID or a dedicated opaque correlation identifier.

---

## HPOS

HPOS is mandatory.

Any change involving orders must be reviewed for HPOS.

Declare compatibility only after tests pass.

Do not write code that requires legacy posts-based order storage.

---

## Checkout Blocks

Checkout Blocks are mandatory.

Do not solve Block Checkout by DOM scraping.

Use supported WooCommerce Blocks/Store API integration points.

Do not bundle WooCommerce runtime packages that should be externalized.

Classic Checkout and Checkout Blocks must share the same backend payment domain logic.

---

## Financial integrity

A WooCommerce order may be marked paid only when a verified PayKassa result matches the immutable payment/invoice snapshot associated with that order.

Validate all applicable data:

- merchant/shop
- provider transaction
- order correlation
- payment environment
- system
- currency
- amount semantics
- credited/confirmed provider status

When evidence is ambiguous:

DO NOT mark paid.

Fail safe to pending/on-hold/manual review and produce diagnostics.

False-negative automation is preferable to a false-positive paid order.

---

## Money

Never compare monetary values with binary floating-point equality.

Use decimal strings and explicit precision.

Use WooCommerce decimal helpers where appropriate.

Crypto precision must not be truncated to ordinary fiat precision.

Never calculate exchange rates yourself unless the project explicitly adds a reviewed, authoritative rate subsystem.

Provider invoice snapshot wins over current global store state.

---

## Payment snapshot

When a PayKassa payment/invoice is created, persist an immutable snapshot sufficient to validate future callbacks.

At minimum:

- Woo order ID
- Woo order currency
- Woo expected amount
- provider invoice/correlation identifier
- provider system
- provider currency
- network
- provider expected amount if supplied
- test/live environment
- creation timestamp
- payment mode

Never revalidate a historical webhook against a newly recalculated exchange rate.

---

## Webhooks

Raw incoming webhook POST data is untrusted.

The only trusted provider evidence is the result of the documented PayKassa server-to-server verification mechanism.

Rules:

- accept only required HTTP methods
- bound input size
- parse minimally
- never trust raw amount/currency/order fields without provider verification
- verify provider response
- verify against stored payment snapshot
- make processing idempotent
- acknowledge PayKassa in exactly the documented format
- never expose stack traces

IP allowlists are defense-in-depth only, not primary authenticity.

---

## Idempotency

All money-changing operations must be idempotent.

Duplicate or concurrent webhook delivery must never cause:

- duplicate `payment_complete()`
- duplicate stock reduction
- duplicate payout
- duplicate refund
- duplicate transaction mutation
- order status regression

Use durable atomic deduplication for provider events.

"Check order meta, then set order meta" alone is not a sufficient concurrency control.

---

## Stock

Do not manually reduce stock if WooCommerce's standard payment lifecycle already handles it.

Audit every stock-changing call for duplicate execution.

Payment retry must not reduce stock twice.

---

## Remote HTTP

TLS verification is mandatory.

Never introduce:

```php
'sslverify' => false
```

Use WordPress HTTP APIs or an explicitly reviewed transport abstraction.

Timeouts must be finite.

Retry only operations known to be idempotent.

Never blindly retry payment/invoice creation after an ambiguous timeout.

Validate external redirect URLs.

Only trusted HTTPS PayKassa destinations may be used for provider redirects.

---

## Secrets

Secrets include:

- merchant password
- API password
- private hashes/tokens
- authorization headers

Never:

- log them
- expose them to JavaScript
- show them in diagnostics
- include them in system reports
- put them in exceptions shown to users
- commit them

Log only redacted/fingerprinted identifiers when correlation is necessary.

---

## Logging

Use WooCommerce logger:

```php
wc_get_logger()
```

Source:

`paykassa`

Log structured context.

Logs should answer:
- what operation happened
- for which Woo order
- which provider transaction
- what state transition
- what safe error code

Do not dump entire API payloads by default.

Debug logging is off by default.

---

## Provider API

Do not depend directly on legacy `paykassa_sci.class.php` behavior.

Verify every provider feature against current official PayKassa documentation/source.

Wrap provider code behind project-owned adapters.

Provider arrays must be converted into typed project DTOs before entering payment business logic.

Do not edit vendor code.

Do not download executable provider code at runtime.

---

## Payment systems

Do not restore the old hardcoded mapping of obsolete numeric system IDs.

Payment/network capabilities must come from the current provider integration or a reviewed local registry/fallback.

Unsupported combinations must be hidden or rejected safely.

Never guess a provider network.

---

## Refunds

`sendMoney()` is not automatically a WooCommerce refund.

Do not declare automated refund support unless current PayKassa semantics prove that a safe refund-to-original-payment-method operation exists.

Never automatically send funds to `address_from` as a generic refund strategy.

Any payout feature is a separate high-risk feature and requires explicit admin confirmation, destination validation, authorization and audit logging.

---

## Subscriptions

Do not claim automatic WooCommerce Subscriptions renewals without a provider-supported tokenized merchant-initiated recurring payment model.

Manual renewal orders may use PayKassa as ordinary checkout payments when WooCommerce permits it.

Do not invent fake payment tokens.

---

## Security

For admin state changes:

- capability checks
- nonce
- POST
- sanitization
- late escaping

For external webhooks:

- no nonce
- provider verification
- replay/idempotency protection
- strict validation

For SQL:

- prepared statements
- internally controlled table names

For output:

- escape based on context
- do not pre-escape stored domain values unnecessarily

Never weaken validation merely to "make a failing test pass."

---

## Error handling

Separate:
- provider error
- configuration error
- validation error
- payment mismatch
- duplicate event
- temporary outage
- programming error

Customer messages must be safe and simple.

Technical details belong in redacted admin logs.

Do not swallow exceptions silently.

Do not expose provider secrets or raw traces.

---

## Reconciliation

Payment recovery is a first-class reliability feature.

If provider history API is available:

- use bounded windows
- focus on pending PayKassa orders
- lock jobs
- use Action Scheduler
- back off on provider errors
- make every reconciliation result idempotent

Do not scan the entire order database repeatedly.

---

## Action Scheduler

Use WooCommerce Action Scheduler for background jobs.

Do not create a competing cron framework.

Scheduled actions must:
- be unique where appropriate
- not multiply on every request
- tolerate retry
- be safe after plugin update

---

## Performance

Do not load checkout assets site-wide.

Do not call PayKassa on ordinary frontend page views.

Do not perform unbounded order/history queries.

Cache stable provider capability data.

Webhook handling should perform only work necessary to durably validate/process/acknowledge the event.

---

## WordPress.org

The release must comply with current WordPress.org Plugin Guidelines.

Third-party PayKassa service use must be clearly disclosed in `readme.txt`.

Do not imply the plugin is an official PayKassa product unless there is explicit authorization.

No hidden telemetry.

No remote executable code.

No unnecessary CDN dependencies.

No development secrets or local artifacts in release packages.

---

## Internationalization

All user-facing strings must be translatable with text domain:

`paykassa`

Keep English source strings clear and professional.

Update POT when UI strings change.

Maintain Russian translation where practical.

---

## Accessibility

Checkout/admin UI must be keyboard accessible.

Async status messages should be accessible to assistive technology.

Do not use color as the only state indicator.

Use semantic buttons/labels.

---

## JavaScript

Use modern JS build tooling only where needed.

Checkout Blocks code must use documented WooCommerce APIs.

No jQuery dependency unless a legacy WooCommerce integration strictly requires it.

No global namespace pollution.

No inline secret/config dumps.

Externalize WooCommerce packages according to current WooCommerce build recommendations.

---

## CSS

Scope styles to PayKassa components.

Do not override generic WooCommerce/theme elements globally.

Respect merchant themes.

Keep checkout CSS minimal.

---

## Tests required for payment changes

Any change affecting payments must add/update tests.

Minimum scenarios:

- valid payment
- invalid provider verification
- wrong order
- wrong merchant
- wrong amount
- wrong currency/network
- duplicate webhook
- late webhook
- cancelled order paid late
- provider timeout
- retry payment
- HPOS
- classic checkout
- Checkout Block

A bug fix without a regression test is incomplete unless technically impossible; document why.

---

## Quality gates

Before considering work complete, run all available:

```text
composer validate
PHPCS
PHPStan
PHPUnit
JS lint
JS tests
asset build
integration tests
```

Also run targeted grep/security audits.

No release with known:
- PHP warnings
- notices
- deprecations in supported versions
- failing tests
- unreviewed TODOs in payment path
- debug dumps
- disabled TLS verification

---

## Legacy code

Legacy code may be replaced aggressively.

Do not preserve poor architecture for source compatibility.

Preserve data/settings/API behavior that existing merchants depend on.

Old comments, obsolete system mappings, insecure transport behavior and PHP 5.x coding patterns should not survive merely because they existed in 1.0.2.

---

## Code review mindset

For every payment-related change ask:

1. Can this mark an unpaid order as paid?
2. Can it process the same payment twice?
3. Can an attacker influence order/payment correlation?
4. Can a provider timeout produce a duplicate invoice?
5. Can it lose a paid order after a missed webhook?
6. Does it work with HPOS?
7. Does it work with Checkout Blocks?
8. Does it leak credentials?
9. Does it behave correctly after upgrade from 1.0.2?
10. Is the behavior covered by tests?

If any answer is uncertain, the change is not done.

---

## Final principle

Do not optimize for "more features".

Optimize for a gateway that merchants can trust with real money for years.
