# AGENTS.md — PayKassa for WooCommerce Agent Policy

## Mission

PayKassa for WooCommerce is **payment infrastructure**. A false-positive payment is materially worse than a temporary false-negative/manual-review state.

Treat every change as code that may move real cryptocurrency value, alter WooCommerce order state, reduce stock, trigger fulfilment, receive duplicated callbacks, survive provider outages and run on stores you do not control.

This root file is the **hard execution policy and map**. Detailed law lives in `docs/engineering/`.


For additional help use files:

1. API.md
2. PaykassaAPI.md
3. PaykassaSCI.md

## Current compatibility contract

Unless the user explicitly changes it:

- PHP 8.1+ runtime minimum.
- WordPress 6.6+ minimum.
- WooCommerce 8.5+ minimum.
- HPOS support is mandatory.
- Classic Checkout support is mandatory.
- Checkout Blocks support is mandatory.
- Latest stable WordPress and WooCommerce must be tested before release.
- As of this handbook audit (2026-09-10), latest stable WordPress is 7.1 and WooCommerce is 11.1.x.
- Production plugin uses the repository's current lightweight runtime autoloader; Composer is development tooling unless an explicit architecture task changes packaging.

Do not silently raise/lower runtime requirements or remove legacy compatibility contracts.

## Instruction precedence

1. System/developer/user instructions.
2. Nearest applicable `AGENTS.override.md` / `AGENTS.md`.
3. This root policy.
4. Routed PayKassa engineering handbook documents.
5. Existing repository conventions when they do not conflict.

Inspect reality before assuming structure or provider semantics.

## Mandatory preflight

Before editing:

1. Read this file completely.
2. Inspect `git status`, relevant source, tests, docs, schema and packaging.
3. Read all handbook files routed by the table below.
4. Read provider reference docs in repository when PayKassa API/SCI semantics are involved.
5. Identify:
   - money/order-state impact;
   - webhook/provider trust boundary;
   - idempotency/concurrency impact;
   - HPOS/Blocks/classic-checkout impact;
   - schema/migration impact;
   - secret/logging impact;
   - backward-compatibility impact;
   - test matrix.
6. Prefer the smallest coherent change.
7. Never rewrite unrelated payment logic, docs or release metadata.

## Handbook routing — mandatory

| Change touches | Read before coding |
|---|---|
| Any non-trivial change | `docs/engineering/01_ENGINEERING_CONSTITUTION.md` |
| Architecture/domain/payment state | `docs/engineering/02_ARCHITECTURE_AND_PAYMENT_DOMAIN.md` |
| PHP/WordPress/WooCommerce/types | `docs/engineering/03_PHP_WORDPRESS_WOOCOMMERCE.md` |
| Amount/currency/network/snapshot | `docs/engineering/04_MONEY_AND_INVOICE_INTEGRITY.md` |
| Callback/IPN/webhook/replay | `docs/engineering/05_WEBHOOK_AND_SETTLEMENT_SECURITY.md` |
| Invoice creation/retry/concurrency | `docs/engineering/06_INVOICE_CREATION_AND_IDEMPOTENCY.md` |
| HPOS/order CRUD/stock/status | `docs/engineering/07_WOOCOMMERCE_ORDER_LIFECYCLE.md` |
| Blocks/classic checkout/UI | `docs/engineering/08_CHECKOUT_BLOCKS_ADMIN_ACCESSIBILITY.md` |
| PayKassa SCI/API/HTTP/provider docs | `docs/engineering/09_PROVIDER_API_AND_TRANSPORT.md` |
| DB/schema/migrations/locks | `docs/engineering/10_DATA_MIGRATIONS_AND_LOCKING.md` |
| Reconciliation/background recovery | `docs/engineering/11_RECONCILIATION_AND_RECOVERY.md` |
| Secrets/logging/diagnostics/privacy | `docs/engineering/12_SECURITY_SECRETS_OBSERVABILITY.md` |
| Tests/QA/chaos/concurrency | `docs/engineering/13_TESTING_AND_QUALITY.md` |
| Performance/availability | `docs/engineering/14_RELIABILITY_AND_PERFORMANCE.md` |
| CI/package/release/dependencies | `docs/engineering/15_CI_RELEASE_SUPPLY_CHAIN.md` |
| README/changelog/version copy | `docs/engineering/16_README_AND_RELEASE_METADATA_POLICY.md` |
| Refunds/subscriptions/payout scope | `docs/engineering/17_HIGH_RISK_FEATURE_POLICY.md` |
| Review/completion | `docs/engineering/18_REVIEW_PLAYBOOK.md` |
| Runtime/provider compatibility | `docs/engineering/19_COMPATIBILITY_MATRIX.md` |

If multiple rows apply, read all of them.

Also read current repository docs when relevant:

- `docs/architecture.md`
- `docs/payment-flow.md`
- `docs/webhook-security.md`
- `docs/testing.md`
- `docs/releasing.md`
- `API.md`
- `PaykassaAPI.md`
- `PaykassaSCI.md`

# CRITICAL: README and release-copy files are protected

## Default rule

Codex MUST NOT modify `readme.txt`, root `README.md`, or root `CHANGELOG.md` unless the user's **current task explicitly authorizes that exact change**.

This includes:

- Description/marketing copy;
- Installation/FAQ/Screenshots;
- external-service/privacy wording;
- `Requires at least`;
- `Tested up to`;
- `Requires PHP`;
- `WC requires at least` / `WC tested up to` references;
- Stable tag;
- Changelog;
- Upgrade Notice;
- formatting/spelling cleanup.

A generic instruction such as “prepare release”, “bump version”, “update docs”, “make versions consistent” or “finish production hardening” does **not** authorize protected README/CHANGELOG edits.

## Version/changelog changes are explicit-only

Version metadata, Stable tag, Changelog and Upgrade Notice inside protected files MAY change only when the user explicitly asks for those exact fields/sections.

If only changelog is authorized, do not rewrite Description/FAQ/privacy copy.

If code and protected README become inconsistent but README was not authorized, report the mismatch and leave it unchanged.

## README guard

This handbook contains SHA-256 baselines and `tools/verify_readme_guard.py`.

Without explicit README authorization, the guard MUST pass.

Never regenerate baseline hashes merely to silence the guard.

Unauthorized protected-file modification is a BLOCKER.

# Absolute payment-integrity law

A WooCommerce order may be marked paid only after **server-to-server provider verification** produces evidence that exactly matches the immutable invoice/payment snapshot and current settlement policy.

Raw callback POST fields are not payment evidence.
Browser state is not payment evidence.
A redirect return page is not payment evidence.
An IP allowlist is not primary authenticity.

When evidence is incomplete, contradictory or ambiguous: **do not fulfil automatically**.

Prefer pending/on-hold/manual review over false-positive payment completion.

# Money law

Never use binary floating-point equality for payment amounts.

Use canonical decimal strings and explicit crypto precision.

Validate all applicable:

- internal Woo order ID;
- merchant/shop context;
- test/live environment;
- provider transaction ID;
- invoice/payment-link identifier;
- provider system/network;
- provider currency;
- expected exact amount;
- provider verification/confirmation state.

Historical callback validation uses the stored immutable snapshot, not current store settings or a newly computed rate.

Do not invent fiat-to-crypto conversion or exchange-rate semantics not established by the reviewed provider contract.

# Strict PHP typing law

All project-owned PHP source MUST remain strictly typed.

Required:

- `declare(strict_types=1);`;
- typed parameters;
- typed returns;
- typed properties;
- `readonly` immutable state where appropriate;
- enums/value objects/DTOs where they reduce invalid payment states;
- precise PHPStan array shapes/generics when native types cannot express shape;
- external/WordPress/provider `mixed` narrowed immediately at boundary;
- no broad PHPStan ignores/baseline growth;
- no dynamic properties.

PHPStan should be raised toward maximum practical strictness; never lower it to pass a patch.

# WooCommerce law

Orders MUST use WooCommerce CRUD/APIs.

Do not directly use `wp_posts`/`wp_postmeta` or raw order post APIs for WooCommerce orders.

Internal Woo order ID is the technical identity. `get_order_number()` is display data.

HPOS and classic data store behavior must remain correct.

Do not call stock-reduction routines manually if `payment_complete()`/WooCommerce lifecycle already owns them.

# Payment state-machine law

Payment states/transitions are explicit.

A paid order/payment state must not regress through ordinary callback/retry processing.

Cancelled/expired/conflicted/late-paid cases require explicit policy and tests.

Never force an ambiguous state into `processing`/`completed` just to satisfy a checkout flow.

# Webhook law

Webhook handling MUST:

- accept only intended method/content;
- bound input size;
- parse minimally;
- format-check provider token;
- verify with PayKassa server-to-server;
- validate verified evidence against immutable snapshot;
- reserve durable unique provider event before settlement;
- survive duplicate and concurrent delivery;
- distinguish duplicate from DB failure;
- acknowledge only according to documented provider protocol;
- never expose trace/secret/raw token.

`payment_complete()` must be protected against duplicate/concurrent execution.

# Invoice-creation law

Invoice/payment creation is a money-changing side effect.

An ambiguous provider timeout MUST NOT be blindly retried if that could create a second invoice.

Use per-order durable reservation/lease/idempotency policy.

A retry may reuse a valid active invoice when safe.

Do not release a lock after ambiguous creation merely to make checkout retry immediately.

# Provider law

Provider semantics come from current reviewed PayKassa documentation/source, not guesses or legacy wrapper quirks.

Provider arrays are normalized into project DTOs before payment domain logic.

TLS verification is mandatory.
Timeouts are finite.
Redirect URLs are restricted to reviewed trusted HTTPS PayKassa hosts.

Do not download/execute provider code at runtime.

# Secret law

Never log/render/expose:

- shop password;
- API password;
- private hash/token;
- auth headers;
- secret request payloads.

Use redacted fingerprints only where correlation is necessary.

Secret setting fields must not reprint stored secrets and must preserve stored secret when blank-save semantics intend that.

# Reconciliation law

Recovery/reconciliation is not an alternative unauthenticated settlement path.

It must use documented provider evidence strong enough to settle, or remain diagnostic-only.

Bound windows/queries, lock jobs, back off on provider error and make recovery idempotent.

Do not scan all Woo orders repeatedly.

# High-risk feature law

Do not claim or implement automated crypto refunds, payouts, saved payment methods or automatic subscription renewals without provider semantics that safely support them and an explicit user task approving the design.

A blockchain sender address is not automatically a safe refund destination.

`sendMoney()` is not automatically WooCommerce refund semantics.

# Testing law

A payment plugin requires layered verification:

- pure unit tests;
- WordPress/WooCommerce integration tests;
- HPOS + classic-store tests where supported;
- Classic Checkout + Checkout Blocks tests;
- provider contract fixtures;
- webhook duplicate/concurrency/replay tests;
- DB failure/lease-expiry tests;
- migration/upgrade tests from 1.x settings;
- ambiguous timeout tests;
- exact-decimal/property tests;
- cancellation/late-payment/manual-review tests;
- reconciliation tests;
- security/adversarial tests;
- browser/E2E checkout tests;
- fault injection;
- package/install smoke.

A five-test unit suite is not sufficient proof for production payment settlement.

# CI law

CI MUST execute real tests, not only syntax/static checks.

Release CI should include minimum and latest supported runtime matrices, real disposable WordPress/WooCommerce integration, package/source parity and final ZIP activation/checkout callback smoke.

Never claim release readiness if critical integration smoke exists only as an unexecuted script.

# Hard blockers

A task/release is NOT complete with any unresolved applicable:

- callback class/file missing from source or package;
- source/package parity failure;
- duplicate `payment_complete()` possibility;
- double stock/fulfilment risk;
- ambiguous invoice creation retried unsafely;
- raw callback data trusted;
- amount/currency/network/snapshot mismatch accepted;
- cancelled late payment silently fulfilled/lost;
- DB lock/event schema inconsistent with runtime SQL;
- migration falsely marked complete;
- secret/token logged/exposed;
- unsafe redirect/TLS weakening;
- HPOS or Checkout Blocks regression;
- underlying Woo checkout broken by diagnostic/reconciliation code;
- mandatory tests/static/build/package checks failing;
- unauthorized README/CHANGELOG modification.

# Definition of Done

All applicable conditions are true:

- requested behavior complete;
- payment invariants preserved;
- source and final package contain required runtime files;
- types remain strict;
- server-to-server verification remains authoritative;
- exact decimal/snapshot matching correct;
- idempotency/concurrency proven;
- Woo order/stock lifecycle correct;
- HPOS/classic/Blocks compatibility tested as applicable;
- migration/upgrade preserves merchant credentials/settings;
- secrets/logs safe;
- failure modes go to safe state;
- positive + negative + duplicate + concurrency tests exist;
- integration suite executed;
- PHPStan/PHPCS/tests/build pass;
- final ZIP installed/activated and payment smoke exercised;
- WP_DEBUG/browser console clean for affected flow;
- README guard passes unless exact README scope explicitly authorized;
- no unrelated diff.

# Required completion report

Report:

1. files changed;
2. payment/order-state behavior;
3. provider-contract assumptions;
4. amount/currency/snapshot implications;
5. webhook/idempotency/concurrency implications;
6. HPOS/Blocks/classic checkout impact;
7. migration/backward compatibility;
8. security/secrets/logging;
9. tests added and exact commands/results;
10. final package/source parity and ZIP smoke result;
11. README guard result/authorization scope;
12. anything not executed and why;
13. remaining real limitations.

Never say “done” without evidence.

# Final rule

For PayKassa, **false-positive settlement is the catastrophic failure class**.

When uncertain, preserve money, order history and merchant visibility; do not silently fulfil.
