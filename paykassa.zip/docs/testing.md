# Testing

Unit tests cover decimal precision, immutable snapshots, state transitions and redirect-host validation. The public CI runs these under PHP 8.1–8.3, syntax validation, PHPCS, PHPStan, JavaScript syntax validation and package creation.

Before release, run a WooCommerce integration suite against the declared minimum and latest stable version with both HPOS stores, classic checkout, Checkout Block, guest/order-pay retry and mocked SCI responses. Exercise valid, invalid, wrong-order, wrong-amount, wrong-currency, duplicate and cancelled-order callbacks. Never use merchant credentials in CI.
