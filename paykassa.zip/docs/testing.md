# Testing

Unit tests cover decimal precision, immutable snapshots, state transitions, redirect-host validation and history response parsing. The public CI runs these under PHP 8.1–8.4, syntax validation, PHPCS, PHPStan, JavaScript syntax validation and package creation. See [the recovery verification report](testing-reconciliation.md) for the latest executed matrix, commands, failure-injection coverage and provider-contract limitations.

PayKassa Test Mode history recovery is unsupported: real sandbox validation returned the exact no-result envelope for a completed SCI payment. The runtime treats only that exact response as an empty scan; `api_get_shop_txids`, history rows and TXIDs are never independent payment evidence. Keep unattended recovery disabled until a controlled live lost-webhook test proves a deterministic, SCI-verified path.

Before release, run a WooCommerce integration suite against the declared minimum and latest stable version with both HPOS stores, classic checkout, Checkout Block, guest/order-pay retry and mocked SCI responses. Exercise valid, invalid, wrong-order, wrong-amount, wrong-currency, duplicate and cancelled-order callbacks. Never use merchant credentials in CI.

The `integration` CI job installs the built plugin ZIP into disposable WordPress/WooCommerce sites (WordPress 6.6 / WooCommerce 8.5.2 on PHP 8.1, and WordPress 7.1 / WooCommerce 11.1.0 on PHP 8.2). It runs the schema-v2 upgrade regression, both existing WP-CLI smoke scripts and recovery regression against a real database. Recovery tests explicitly switch HPOS off/on, assert the actual store, and exercise two independent PHP settlement workers plus real Action Scheduler batch execution. This job does not yet constitute browser checkout E2E or external PayKassa sandbox verification.

The payment smoke also runs with HPOS off/on. Its invoice-lifecycle matrix covers explicit `preparing -> creating -> created`, active reuse, schema-v3 `expires_at=""` hash compatibility, retirement and one replacement, a verified late payment for the retired invoice, ambiguous SCI timeout fencing, explicit merchant release, definitive provider rejection, stale pre-provider lease reclaim, rejection of the stale owner's final pre-SCI CAS, connection-mutex blocking of premature manual release and stale post-provider non-reclaim. Provider transport remains mocked; this does not prove a PayKassa hosted-link TTL because the published SCI response contains no expiry field.

The same installed-site smoke creates an unfinished Test Mode invoice with secret A, changes current settings to secret B/Live Mode, and asserts that order-scoped routing makes exactly one verification call with retained secret A/Test Mode before normal idempotent settlement. It also verifies the once-seeded legacy context used by pre-versioning snapshots. Raw callback fields remain routing hints only; the provider response must return the same order identity.

Run the same integration entry point locally with a test database account allowed to create and drop databases:

```bash
npm run plugin-zip
composer test:integration
```

Optional environment variables: `PAYKASSA_TEST_DB_HOST` (default `localhost`), `PAYKASSA_TEST_DB_USER` (default `root`), `PAYKASSA_TEST_DB_PASSWORD`, `PAYKASSA_TEST_WP_VERSION`, `PAYKASSA_TEST_WC_VERSION`, and `PAYKASSA_TEST_PLUGIN_ZIP`. Use a local/CI test server, never production credentials. The runner creates a new temporary site and uniquely named database, then drops only that database on exit. The temporary site files remain available for diagnosis at the printed path.

`tests/fixtures/schema-v2.php` is an independent historical schema fixture with no `owner_token` column in either PayKassa table. The regression sets the stored schema option to the literal `2` and calls `Plugin::register()` (the normal file-update path). It verifies automatic migration to `3`, nullable `char(64)` columns in both tables, preserved settings and financial records, functioning token-based SQL, idempotent reruns, and no DDL on subsequent current-version requests. A real SQL error injected into the second table's ALTER verifies that a partially failed migration retains version `2` and succeeds on the next registration. The script refuses to reset tables outside the disposable test database.

## Schema-v3 verification (2026-09-10)

The regression first failed with `SCHEMA_VERSION = '2'` at the assertion that ordinary plugin registration must upgrade the stored version to `3`. After the version bump, all three integration scripts passed against the installed ZIP on both WordPress 6.6 / WooCommerce 8.5.2 and WordPress 7.1 / WooCommerce 11.1.0, using local PHP 8.2.12 and MariaDB 10.4.32. Both databases were disposable and removed afterwards. The PHP 8.1/MySQL 8 combination is configured in CI; it was not executed locally or claimed as a completed GitHub Actions run.

Commands executed successfully:

- `composer validate --strict`, `composer syntax`, `composer lint`, `composer stan`, `composer test` (8 unit tests, 33 assertions).
- `vendor/bin/phpcs --standard=phpcs.xml.dist tests/Integration/wp-cli-schema-upgrade.php tests/fixtures/schema-v2.php tests/fixtures/disposable-site.php`; PHP syntax checks for these files; `bash -n scripts/test-integration.sh`.
- `npm test`, `npm run build`, `npm run plugin-zip`.
- `LD_PRELOAD=/lib/x86_64-linux-gnu/libwebp.so.7 composer test:integration`.
- `PAYKASSA_TEST_WP_VERSION=6.6 PAYKASSA_TEST_WC_VERSION=8.5.2 LD_PRELOAD=/lib/x86_64-linux-gnu/libwebp.so.7 bash scripts/test-integration.sh`.
- `python3 tools/verify_readme_guard.py`, workflow YAML parsing and `git diff --check`.

All 37 production `src/` files plus the entry point, uninstall script and Blocks asset were byte-compared with the ZIP; the new test files are excluded. The runtime change only advances the schema version: provider contracts, settlement/stock behavior, decimal/snapshot validation and checkout integrations are unchanged by this patch. Existing settings and records were compared before/after migration, including unfinished leases and completed event records.

Local test-environment observations: XAMPP's bundled WebP library conflicts with the system image library during a fresh WooCommerce installation; the command-scoped `LD_PRELOAD` above resolves that without changing the plugin or host configuration. The WordPress 7.1 / WooCommerce 11.1.0 installation emits a WooCommerce early-translation notice before PayKassa installation. It was not suppressed or represented as a clean PHP log. No browser/E2E tests were rerun for this schema-version-only runtime change; this verification does not certify the plugin's other outstanding production-hardening work.
