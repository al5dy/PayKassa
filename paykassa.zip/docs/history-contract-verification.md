# PayKassa history contract verification — 2026-09-11

## Decision

**Unattended history recovery remains blocked.** A real PayKassa Test Mode SCI payment completed successfully for WooCommerce order `139` / PayKassa transaction `292205`, but `api_get_history` returned exactly `{"error":true,"message":"No data"}` for all four tested `test=0|1` and `status=yes|no` combinations over the relevant seven-day range. The order was already paid through the normal server-verified callback path; this observation does not demonstrate history recovery.

The same controlled sandbox validation showed that `api_get_merchant_info` accepts the configured API credentials. It also showed that `api_get_shop_txids` returns synthetic TXIDs for arbitrary fake numeric invoice IDs (`987654321`, `555555555`, `314159265`). A returned TXID therefore does not prove that an invoice or payment exists in Test Mode and must never create `PaymentEvidence` or trigger settlement.

These real sandbox results were supplied from the merchant's current sandbox/ngrok setup. The earlier local observation-tool run described below still had no credentials and made no authenticated request; its historical result is retained rather than misrepresented as the source of the new evidence.

## Provider evidence reviewed

| Source | What it establishes / does not establish |
| --- | --- |
| [Official PHP history example](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/examples/get_history.php) and [API adapter](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/src/PaykassaAPI.php) | `api_get_history`, merchant, incoming/success filters, dates, zero-based page and `data.list/page_count`. The example prints items without defining their fields. No promise of `order_id`, `private_hash`, invoice identity, environment or ordering stability. |
| [Official SCI adapter](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/src/PaykassaSCI.php) and [SCI/API documentation](https://paykassa.pro/docs/) | Both `sci_confirm_order` and `sci_confirm_transaction_notification` require a private hash. The latter is documented as live-only. It is not a token-free lookup by transaction ID. |
| [Official Node.js merchant adapter](https://github.com/paykassa-dev/nodejs-api-sdk/blob/0f01b317fd16f91123e73bbbc0175c542f6500ba/lib/merchant.js), [payment adapter](https://github.com/paykassa-dev/nodejs-api-sdk/blob/0f01b317fd16f91123e73bbbc0175c542f6500ba/lib/payment.js), [Go merchant adapter](https://github.com/paykassa-dev/golang-api-sdk/blob/dcd7c42f7692baa033c6d22d0522c25f007e14b6/api/merchant.go) and [payment adapter](https://github.com/paykassa-dev/golang-api-sdk/blob/dcd7c42f7692baa033c6d22d0522c25f007e14b6/api/payment.go) | No additional history contract or token-free incoming-payment verification method was found in these reviewed adapters. This does not assert that PayKassa cannot offer another mechanism through provider support. |

The current docs page loads [a JavaScript documentation bundle](https://paykassa.pro/docs/assets/main.bundle.js?20250903). Its SHA-256 during this review was `2ea62da99e3f7b675c942ed0a0717ee09230a5c88d371cefc15bd1953aa203b4`. Its method definitions do not include `api_get_history`. The repository's `API.md`, `PaykassaAPI.md` and `PaykassaSCI.md` were also consulted for the relevant semantics.

`api_get_shop_txids` returns invoice-to-blockchain-txid mappings, including synthetic mappings for arbitrary fake invoice IDs in the validated sandbox. It does not supply the complete incoming-payment evidence required by the stored hosted-invoice snapshot. A TXID, public payment-link hash or successful history filter is not a replacement for SCI verification.

## Sandbox observation tool

`tools/probe_paykassa_history.php` is a development CLI, excluded from the plugin ZIP. Provide `PAYKASSA_SANDBOX_API_ID`, `PAYKASSA_SANDBOX_API_PASSWORD` and `PAYKASSA_SANDBOX_SHOP_ID` through the local process environment, never command-line credential arguments or committed files. Use credentials belonging to a test merchant.

```bash
php tools/probe_paykassa_history.php \
  --from=2026-09-01T00:00:00Z --to=2026-09-11T00:00:00Z --page=0
```

It requests exactly one page of `api_get_history` with `test=1`, `type=pay_in` and `status=yes`. It permits at most a 31-day range, enforces HTTPS/TLS validation, disables redirects and bounds connect/total timeouts and response size. It uses isolated cURL so loading a store's WordPress plugins or debug HTTP hooks cannot export the credentials. It has no invoice, settlement, scheduler or database path.

The output describes each item separately and preserves observed JSON field types, including string versus numeric amounts. It never exports scalar field values or provider error messages. Recognized field names are printed only when actually present; unknown names become positional `unknown_field_N` labels because arbitrary map keys can themselves contain secrets. These labels require a local, controlled provider-contract review before adding new recognized fields. The tool does not silently fabricate missing fields. Only the requested test flag is reported; actual isolation of history by environment remains to be verified with the provider.

The exact provider result `error=true`, `message="No data"` is reported as an empty observation with `provider_result=no_data`; it is not treated as an outage and still retains `release_ready=false`. Similar messages, additional unexpected fields, authentication failures, permission failures and malformed responses remain errors. An empty page or shape observation is never payment evidence.

The earlier local invocation above exited **1**, with `reason=missing_sandbox_credentials`, before any HTTP request. Authentication errors and malformed responses are never represented as a successful contract test.

## Required evidence to unblock

1. A controlled **LIVE** incoming payment whose webhook is deliberately withheld from an isolated WooCommerce order. Test Mode history is now known not to expose the completed sandbox payment.
2. Actual live history items from that payment, including their original field types, plus PayKassa's guarantee of identity, environment and confirmation semantics. If no private hash is supplied, a documented supported verification lookup with its request/response contract is needed.
3. An explicit transaction-to-snapshot mapping. Amount/currency/time or customer display order numbers alone cannot establish order identity. Where identity is ambiguous, keep a reconciliation review diagnostic; do not change an arbitrary candidate order to paid or on-hold.
4. Reviewed sanitized samples with provenance, then automated contract/integration tests exercising recovery, duplicate recovery, later webhook, conflicting identities and wrong amount/network/environment against those samples.
5. A successful controlled live lost-webhook recovery run and applicable checkout/release gates before changing the release-readiness wording.

## Current hardening changes

- Normalize only the exact first-page `api_get_history` no-result envelope to an empty page. Reconciliation reports `completed`, `checked=0`, removes its job and does not enter outage backoff.
- Keep every other provider error fail-closed. Authentication/permission errors, malformed envelopes, transport failures and non-exact `No data` variants still fail and back off.
- Keep `api_get_shop_txids` absent from the runtime API adapter and add a trust-boundary regression proving synthetic invoice/TXID mappings cannot become verifiable candidates or `PaymentEvidence`.
- Mark Test Mode history recovery unsupported and unattended live recovery unverified in gateway settings and diagnostics. The opt-in remains disabled by default.

This hardening does not change production settlement, money/decimal/snapshot rules, webhook deduplication or locking. No schema, credential migration, runtime minimum, autoloader or version metadata changes. Root README/readme.txt/CHANGELOG remain protected and untouched.

## Executed verification

All local PHP executions used PHP 8.2.12. Integration ran against real disposable WordPress/WooCommerce databases and the installed ZIP; provider responses in that automated suite were synthetic. The real sandbox results at the start of this report were supplied by the merchant and were not replayed with credentials during this hardening run.

| Command | Result |
| --- | --- |
| `composer validate --strict` | PASS |
| `composer test` | PASS: 57 tests, 133 assertions |
| `composer syntax` | PASS, all 43 production PHP source files |
| Targeted `php -l` and `vendor/bin/phpcs` on all changed PHP files | PASS |
| `composer lint`, `composer stan` | PASS; existing PSR12 configuration and PHPStan level 5, no new ignores/baseline |
| `msgfmt --check-format` | PASS for `languages/paykassa-ru_RU.po` |
| `composer audit --locked`, `npm audit --omit=dev` | No vulnerability advisories |
| `npm test`, `npm run build`, `npm run plugin-zip` | PASS |
| `LD_PRELOAD=/lib/x86_64-linux-gnu/libwebp.so.7 bash scripts/test-integration.sh` | PASS: WP 7.1 / WC 11.1.0, 430 recovery assertions with HPOS OFF and 430 with HPOS ON |
| `PAYKASSA_TEST_WP_VERSION=6.6 PAYKASSA_TEST_WC_VERSION=8.5.2 LD_PRELOAD=/lib/x86_64-linux-gnu/libwebp.so.7 bash scripts/test-integration.sh` | PASS: 430 recovery assertions with HPOS OFF and 430 with HPOS ON |
| ZIP/source/installed-site byte comparison and denylist | PASS: all 56 packaged files matched source and both installed sites; 46 required runtime files present |
| `python3 tools/verify_readme_guard.py`, `git diff --check`, shell syntax checks | PASS |

Both integration installations also passed fresh activation/schema validation, v2-to-v3 migration with failed-DDL recovery, legacy settings migration, invoice/IPN/duplicate/late-payment smoke, two-process settlement concurrency and Action Scheduler lifecycle checks. The new assertions prove exact `No data` completion with zero checked records, no backoff/error marker and no payment completion; a provider authentication error still fails with a retained backoff checkpoint. Reconciliation remains disabled by default. Disposable databases were dropped by the runner; site files remain at `/tmp/paykassa-integration.TikgJuUF` and `/tmp/paykassa-integration.NM6r00ZX` for inspection. Neither site produced a `wp-content/debug.log`.

Artifact: `dist/paykassa-2.0.0.zip`, SHA-256 `2a0a71d2d3d982e170457a94d383714d433f5c99ce476dd686adabb3cb80ff0f`. The package excludes tools/tests/docs/scripts/vendor/node_modules/dist/Git/IDE data. The integration matrix installed and activated this ZIP rather than loading the plugin from the source tree.

Unexecuted: a controlled live lost-webhook payment, provider-backed live history fixtures, browser Classic/Blocks E2E, PHP 8.1/8.3/8.4 local runtime matrix, WordPress Plugin Check and remote GitHub Actions. Classic invoice/shared settlement backend ran in both installed-site matrices, but this is not browser checkout certification. The WP 7.1 / WC 11.1.0 install emitted WooCommerce's early-translation notice before PayKassa installation; no PayKassa debug-log entry was produced. npm's environment-owned `min-release-age` warning also persists.

Remaining limitation: real Test Mode history did not expose the completed sandbox payment, and no evidence yet establishes that live history supports the discovery fields consumed by the current recovery pipeline or supplies an alternative strong verification path. Unattended recovery remains **not release-ready** until a controlled live lost-webhook test succeeds.
