# Recovery decision — 2026-09-11

Follow-up: [history contract verification](../history-contract-verification.md) records the provider-source audit, real sandbox observation and safe observation tool. Test Mode history returned no data for a completed SCI payment, while the TXID lookup returned synthetic values for arbitrary fake invoice IDs. The provider release constraint below remains in force pending a controlled live lost-webhook test.

## Provider contract and release constraint

Reviewed the official [PHP SDK history example](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/examples/get_history.php), [API adapter](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/src/PaykassaAPI.php), [developer page](https://paykassa.pro/en/developers/) and [SCI documentation](https://paykassa.pro/docs/). The published history example establishes `type=pay_in`, `status=yes`, `shop_id`, ISO dates, zero-based `page_num`, `data.list` and `data.page_count`. It **does not describe a history row's fields or promise a private verification token**. The example also increments the page number without performing another request; this implementation actually requests subsequent pages.

`sci_confirm_order` does document order ID, merchant, transaction, payment-link hash, amount, currency, system and partial-payment semantics. Therefore history is discovery, not an alternative settlement authority. No history amount, `status=yes`, TXID or guessed invoice identifier can mark an order paid. `api_get_shop_txids` is deliberately not exposed by the runtime adapter and cannot create `PaymentEvidence`; do not map a returned TXID or stored public payment-link hash to a missing private hash.

The candidate adapter conditionally recognizes `order_id` and `private_hash` **if present** and obtains fresh SCI verification. These row fields are an explicit, unconfirmed discovery prerequisite, not a claim about the upstream history response. Unknown records are counted as `unverifiable`; they prevent advancement of the recovery watermark and cannot produce a successful-recovery timestamp. The exact first-page provider result `error=true`, `message="No data"` is normalized to an empty completed scan; no other provider error receives this treatment. Synthetic candidate fixtures prove the pipeline, not the missing provider capability.

## Common settlement

Webhook and recovery invoke the same `WebhookProcessor`. Its outcome distinguishes processed, duplicate, manual-review and retry, independently of the provider ACK. Both paths validate immutable snapshot and current order amount/currency. SCI evidence carries its verification environment. Recovery uses the invoice's environment for SCI, even if current checkout settings differ. Historical SCI password retention is not implemented here; rotated/revoked credentials fail closed. Discovery of old-environment records by the history endpoint is also not asserted without a provider contract.

Payment completion is serialized per order by a connection-bound MySQL/MariaDB named mutex, before state is read through WC CRUD. Event ownership tokens/leases remain durable; a slow live settlement worker is no longer superseded solely by a lease timer. All calls use the same writer connection; database proxies that split sessions or do not support named locks are not supported and must not be claimed compatible. Lost ownership/release/update failures cause retry. This is cooperative locking between PayKassa workers, not a transaction over arbitrary third-party WooCommerce hooks or external fulfilment services.

The WC order is reloaded after `payment_complete()` and must actually be paid with the expected transaction before the event can be finalized. A saved-metadata/unpaid-WC boundary can resume. Failure to finish an event remains retryable, and a replay of an already committed payment does not invoke payment completion again. Separate verified transactions are retained for review without regressing a paid order. No custom stock reduction is used.

## Checkpoints and scheduling

- Opt-in only, with separate API credentials plus SCI verification credentials.
- Initial lookback: 30 days, bounded administrator selection 7/30/90/365. Trusted PHP callers may pass explicit ISO date ranges to `run($from, $to)` for backfill; there is no unauthenticated recovery endpoint.
- Later scans start at the saved watermark with one-day overlap, not at `now - 24h`. Outages do not move the watermark. Unverifiable records prevent watermark advancement.
- At most five page requests, ten candidates, and a 40-second between-request time budget per invocation; each individual request has a 20-second timeout. Maximum accepted page count 10,000; maximum page size 1,000; maximum response 2 MiB. Unexpected counts, empty intermediate pages and repeated pages fail closed.
- Durable cursor stores frozen range, page, offset, page fingerprints, retry time and counters, never raw rows or private tokens. Changed pages replay safely. Provider page ordering/insertion stability is not documented; overlapping rescans help but do not establish a completeness guarantee for a changing provider dataset.
- A connection-bound run mutex coordinates overlapping jobs. Cursor persistence is checked. The exact first-page `error=true`, `message="No data"` response completes with zero checked records and no backoff. All other provider/transport/malformed-response errors leave the row retryable with exponential backoff (5 minutes to 6 hours).
- Action Scheduler handles continuation jobs; scheduling after an AS completion avoids its running-action uniqueness guard. A pending/running lookup and creation are additionally serialized by a database mutex because older AS hybrid stores fall back to non-unique creation even when the public `unique` argument is true. Scheduling failures are reported without breaking checkout bootstrap. Deactivation/disable remove only PayKassa jobs and retain financial records/checkpoint. Reactivation resumes the checkpoint.

No custom-table schema changed: version 3 and the v2-to-v3 migration are unchanged. New data is in non-autoloaded options and WC CRUD metadata. Source version, protected README/changelog and compatibility claims are unchanged.

## Verification

The recovery regression installs the release ZIP into real disposable WP/WC databases and explicitly runs HPOS OFF and ON. It covers pagination/batching, missing callbacks, repeat history + later webhook, BTC/ETH with changed global currency and custom display numbers, additional payment, negative evidence, cancellation, environment context, malformed pages, API backoff, fault before WC completion, DB failure at event finalization, and two PHP processes competing after lease expiry. It makes no real PayKassa requests or real payments.
