# SCI credential rotation decision — 2026-09-12

## Problem and provider boundary

PayKassa's documented payment callback contains `private_hash`, `order_id`, `system` and `currency`, but those raw values are not payment evidence. `sci_confirm_order` also requires the merchant ID, merchant secret and Test/Live flag before it returns authoritative payment facts. Verifying every callback with today's gateway settings therefore strands an unfinished invoice after a merchant-secret or Test Mode change.

The raw `order_id` may be used only as a bounded routing hint. The plugin loads that WooCommerce order through CRUD, obtains credential contexts from its immutable active/retired snapshots or unresolved creation attempt, and selects a retained SCI profile. Provider verification must then return the same technical order ID, merchant, environment, payment-link hash, amount, currency and network required by normal snapshot settlement. A forged routing hint cannot itself settle any order.

## Credential identity and retention

New invoices use a secret-specific HMAC credential context derived from merchant ID, Test/Live environment and SCI secret using the WordPress auth salt. The context, not the secret, remains in the immutable snapshot and event identity. The corresponding retrievable SCI profile is stored in a dedicated non-autoloaded WordPress option because verification after rotation is impossible from a one-way fingerprint alone.

Before any normal update of `woocommerce_paykassa_settings`, an option-level rotation guard retains the old profile. Invoice creation also refuses to cross the remote side-effect boundary unless its exact profile has been persisted successfully. Gateway admin save adds a merchant-facing error if retention fails.

Retention is read-mostly. If the secret-specific profile already matches and any requested legacy alias already exists, `retain()` returns its context without acquiring the global credential-store mutex. A missing or changed profile takes the mutex, evicts the option/negative/autoload caches, re-reads under the lock and only then persists. This double-check keeps concurrent additions from being overwritten while preventing an unrelated credential write from causing an existing-profile checkout failure.

Pre-versioning snapshots used `hash(shop_id + environment)` and did not distinguish secrets. Upgrade seeds that legacy alias exactly once with the currently configured secret. Later rotations never overwrite it. If the original secret was already lost before this upgrade, the plugin cannot reconstruct it; affected evidence remains fail-closed/manual rather than being verified with guessed credentials.

## Bounds and secret handling

Credential selection is restricted to contexts referenced by the routed order; there is no global try-every-secret fallback. At most eight distinct contexts are attempted for one callback to bound amplification against PayKassa. Excessive or malformed state fails closed.

Retained secrets are never placed in order meta, logs, diagnostics, event rows, frontend output or callback responses. They remain in the WordPress options database alongside the gateway's current secret and are removed when the merchant-authorized uninstall cleanup removes plugin data. Default uninstall behavior remains conservative, so stores that retain plugin settings also retain the credential profiles needed to verify late callbacks.

## Reconciliation

Any reconciliation candidate that contains a documented verification token uses the same order-scoped credential resolver. History data remains only a hint; credential routing does not upgrade it into payment evidence. Unattended reconciliation remains disabled by default and uncertified until the documented live validation is completed.
