# Hosted invoice lifecycle decision — 2026-09-11

## Provider boundary

The reviewed PayKassa SCI 0.4 `sci_create_order` contract returns `url`, `method` and `params.hash`. It does not return an invoice expiration timestamp, a validity duration, an idempotency key or a documented lookup that can prove the outcome of a timed-out create request. The official [`PaykassaSCI::createOrder()` implementation](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/src/PaykassaSCI.php) sends amount, payment system, currency, order ID and comment and exposes no status lookup. The official [`PaykassaAPI` adapter](https://github.com/paykassa-dev/paykassa-modules/blob/1b3b4d4a0dcda0769b9bca7fef5bb131c923fbb8/src/PaykassaAPI.php) likewise has no authoritative create-outcome lookup by WooCommerce order ID.

Consequently, currency-quote age is not invoice lifetime. The plugin must not invent a TTL, probe the customer redirect as payment evidence, or use `api_get_shop_txids` to release an ambiguous create. New snapshots store `expires_at=null` when SCI supplies no expiry. A provider expiry may be applied automatically only if a future reviewed contract returns an authoritative timestamp that was stored in that immutable snapshot.

## Durable lifecycle

The per-order lifecycle is:

```text
preparing -> creating -> created -> expired
    |           |           |
    v           v           +-> manual review (unsafe redirect)
  failed     uncertain
    ^           |
    +-----------+  explicit merchant confirmation only
```

- `preparing` is before the remote side-effect boundary. Only an expired `preparing` lease may be reclaimed automatically.
- `creating` means the request may have reached PayKassa. A caught timeout/malformed response, or an expired `creating` lease after a worker crash, becomes `uncertain`; it is never automatically reclaimed.
- Every create path additionally holds a connection-bound database mutex from before the lease read through SCI response persistence. Immediately before SCI, the worker must pass both the owner-token compare-and-swap (`preparing -> creating`) and a database-mutex ownership check. A stale `preparing` owner therefore cannot call SCI after another worker reclaims its lease, and manual `uncertain -> failed` resolution cannot run while the original worker still owns the mutex.
- `created` requires a successful provider response, an immutable snapshot and the exact snapshot hash in the lifecycle record. An active snapshot plus trusted redirect is reused.
- `failed` is limited to pre-provider failures or a documented SCI `error=true` rejection. It is retryable.
- `expired` means a known invoice was explicitly retired. Because SCI supplies no expiry, normal hosted invoices reach this state only through a capability/nonce-protected merchant action after the merchant confirms that the link is unusable.
- `uncertain -> failed` is a separate capability/nonce-protected merchant action whose wording requires confirmation in PayKassa that no usable invoice exists. This is an operator assertion, not provider verification.

The Woo order records the visible states `invoice_creating`, `invoice_created`, `awaiting_payment`, `invoice_uncertain`, `invoice_failed`, `expired`, `manual_review` and `paid`. Attempt metadata contains only non-secret order/payment/quote context and timestamps. Manual resolution records actor ID, time and reason.

## Replacement and late-payment policy

Retiring a created invoice archives its immutable snapshot before clearing the active snapshot and redirect. The next checkout can atomically claim the `expired` lifecycle row and create one replacement. Old and replacement payment-link hashes remain distinct identities.

An SCI-verified payment that exactly matches a retired snapshot is acknowledged and recorded, but it does not call `payment_complete()` automatically. The order moves to manual review. Any later payment while that verified conflict remains unresolved also stays manual, preventing two payable invoices from producing unattended fulfilment. Event reservation and the normal settlement mutex still provide duplicate/concurrency protection.

An uncertain create without a returned payment-link hash cannot be retroactively turned into an immutable invoice snapshot. If the merchant resolves it and an unknown old invoice is later paid, it cannot match the replacement snapshot and remains fail-closed/manual-review evidence.

## Compatibility and schema

No database DDL is required: the existing `status varchar(16)`, lease, owner token and snapshot hash columns represent the new states. Existing `creating` rows are treated conservatively as having crossed the provider boundary. Existing active snapshots whose unknown expiry was serialized as `""` retain their schema-v3 snapshot hash and remain reusable; reading them normalizes the domain value to `null`.

WooCommerce order data continues to use CRUD APIs, so the lifecycle is the same for HPOS and legacy order storage. Classic Checkout and Checkout Blocks both call the same `OrderPaymentService` and therefore share the same fence and retry rules.

## Verification scope

Disposable database tests cover HPOS off/on for active reuse, legacy snapshot-hash reuse, manual retirement and one replacement, provider-verified payment for the retired invoice, ambiguous timeout blocking, explicit uncertain resolution, definitive rejection retry, stale-owner rejection at the final pre-SCI compare-and-swap, connection-mutex blocking of premature manual release, expired `preparing` reclaim and expired `creating` non-reclaim. These tests mock provider transport. No real PayKassa timeout or expired hosted-link scenario was executed, and no undocumented provider expiry/status behavior is claimed.
