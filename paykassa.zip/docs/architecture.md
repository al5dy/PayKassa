# Architecture

`paykassa.php` is a small bootstrap and autoloader. `Gateway` is the WooCommerce boundary, `PayKassa` contains typed adapters, `Order` owns immutable payment state, and `Webhook` owns verification and durable deduplication. `Admin`, `Blocks`, and `Reconciliation` depend on these layers rather than containing payment decisions.

Orders are accessed only with WooCommerce CRUD. The custom `paykassa_events` table stores only a transaction ID, token fingerprint, order ID, lifecycle status and timestamps; it never stores secrets or request bodies.

Current documented SCI `createOrder` accepts a crypto amount. The plugin therefore intentionally does not construct fiat-to-crypto quotes or direct-address quotations.
