# Architecture

`paykassa.php` is a small bootstrap and autoloader. `Gateway` is the WooCommerce boundary, `PayKassa` contains typed adapters, `Order` owns immutable payment state, and `Webhook` owns verification and durable deduplication. `Admin`, `Blocks`, and `Reconciliation` depend on these layers rather than containing payment decisions.

Orders are accessed only with WooCommerce CRUD. The custom `paykassa_events` table stores only a transaction ID, token fingerprint, order ID, lifecycle status and timestamps; it never stores secrets or request bodies.

SCI `createOrder` accepts a crypto amount. For an explicitly enabled fiat or other supported order currency, `CurrencyRateClient` obtains a one-time quote from PayKassa's official Currency API, then SCI receives only the resulting crypto amount and selected network. The immutable snapshot retains both order money and payment money; no WooCommerce order amount or currency is changed.

Hosted creation uses a durable two-phase boundary plus a connection-bound per-order mutex. `preparing` is reclaimable before SCI, but a stale owner must pass an owner-token CAS and mutex check immediately before the remote call. `creating` may have produced a provider side effect and can only become `created`, `failed` from an explicit provider rejection, or fail-closed `uncertain`; manual release is blocked while the original mutex owner is alive. PayKassa SCI exposes no documented invoice TTL/status lookup, so unknown expiry is never inferred from quote age; merchant-confirmed retirement archives the old snapshot before one replacement. See [the lifecycle decision](architecture/invoice-lifecycle-decision.md).

SCI credentials are versioned independently from current gateway settings. A callback's raw order ID is used only to route to contexts referenced by that order; the selected retained secret/Test Mode profile must still produce authoritative SCI evidence that matches the immutable snapshot. See [the credential-rotation decision](architecture/sci-credential-rotation.md).
