# Reconciliation verification — 2026-09-11

For the subsequent provider-contract audit, real sandbox observation and additional identity regressions, see [history contract verification](history-contract-verification.md). Test Mode history returned `error=true`, `message="No data"` for a completed SCI payment, and the TXID lookup returned synthetic values for arbitrary fake invoice IDs. Unattended recovery therefore remains disabled by default and blocked pending a controlled live lost-webhook test.

## Outcome and remaining release blocker

`ReconciliationService::run()` now consumes history pages, locates candidate orders with WooCommerce CRUD, verifies candidate tokens through SCI, and submits verified evidence to the **same** settlement processor used by callbacks. It persists a resumable cursor, reports outcomes, prevents overlapping runs and backs off on failures. It no longer treats an HTTP success as proof of recovered payments.

**Unattended PayKassa recovery is not certified or release-ready.** The official history example documents the pagination envelope, not the fields of a history record or a way to obtain its private SCI verification token. Real sandbox history exposed no record for the completed test payment. `HistoryCandidate` conditionally consumes `order_id`/`private_hash` if supplied and then requires fresh SCI verification; it does not assume those fields exist. Synthetic candidate fixtures establish consumer/settlement behavior only. Records without adequate verification remain `unverifiable`, do not mark orders paid and do not advance the recovery watermark. `api_get_shop_txids` is not a recovery fallback or payment evidence.

See [the architecture decision](architecture/recovery-decision.md) for source links and exact trust boundaries. Root README, readme.txt and CHANGELOG remain protected and unchanged; any broader recovery claims in them are not substantiated by these local tests.

## Executed matrix

All executions used **PHP 8.2.12 and MariaDB 10.4.32**, a newly created disposable database/site and the installed release ZIP—not the source tree as the active plugin. The test asserts the actual HPOS setting instead of merely naming a test “HPOS”.

| WordPress | WooCommerce | Order store | Result |
| --- | --- | --- | --- |
| 6.6 | 8.5.2 | Legacy | PASS, 398 recovery assertions |
| 6.6 | 8.5.2 | HPOS | PASS, 398 recovery assertions |
| 7.1 | 11.1.0 | Legacy | PASS, 398 recovery assertions |
| 7.1 | 11.1.0 | HPOS | PASS, 398 recovery assertions |

Each installation also passed existing invoice/IPN smoke, the 1.0.2 settings upgrade smoke and the real schema-v2-to-v3 regression (including failed DDL/retry). The final databases were dropped by the runner. Temporary site files remain at `/tmp/paykassa-integration.ypixSSK7` and `/tmp/paykassa-integration.4AqBQG8C` for inspection; these are not live shops.

The existing GitHub integration job invokes the amended runner, so both HPOS modes and the new recovery/concurrency tests are CI gates for the configured version pairs. GitHub Actions itself was not triggered here. Local PHP 8.1/8.3/8.4 runs were not performed; the configured PHP matrix is not presented as executed evidence.

## Coverage

- Twelve lost-webhook payments across two history pages and two bounded invocations; persisted page/row offset and no token in the checkpoint.
- Repeated backfill, webhook after recovery, stable order notes and no extra `woocommerce_payment_complete` effect.
- BTC and ETH (registered by a test MU plugin as a currency extension would do), changed global currency, internal IDs despite modified display numbers.
- Additional verified payment retained for manual review; a transaction already bound to another order is not an acknowledged duplicate.
- Wrong amount/currency/system/merchant/payment-link hash/order; changed order amount/currency; partial payments; missing/invalid tokens; wrong verification environment.
- Cancelled late payment, including a second transaction after the order became on-hold; no automatic fulfilment.
- Invoice-bound SCI Test/Live verification context. This does not prove discovery of old-environment records or survival of SCI password rotation.
- Exact sandbox `No data` normalization to `completed` / `checked=0`, plus provider timeout, non-exact provider errors, backoff without requests, replay from unchanged cursor, invalid/empty/repeated pages, missing credentials and disabled recovery.
- Saved-payment-metadata failure before WC payment completion; successful retry.
- Actual SQL failure on event finish after WC payment committed; retry finalizes as duplicate without another settlement.
- Two independent PHP processes: a webhook worker pauses after order save, its event lease is expired in the DB, recovery attempts settlement, then the original worker resumes. The order mutex prevents concurrent settlement and the subsequent recovery is a duplicate.
- Scheduler uniqueness and cleanup confined to PayKassa jobs. Three actual Action Scheduler executions consume 25 candidates in bounded batches; every action must complete, exactly one continuation must be pending, and the final cursor must be removed. Unknown records still require review, not settlement.

## Commands actually executed

| Command | Final result |
| --- | --- |
| `composer validate --strict` | PASS |
| `composer syntax` and explicit `php -l` on entry point/uninstall/new integration files | PASS |
| `composer test` | PASS: 29 tests, 59 assertions |
| `composer lint` | PASS, existing configured PSR12 rules; not a claim of a new WPCS audit |
| `composer stan` | PASS, level 5 on all 40 production source files, no new ignores/baseline |
| `vendor/bin/phpcs --standard=phpcs.xml.dist tests/Integration/wp-cli-reconciliation.php tests/fixtures/reconciliation-worker.php tests/fixtures/disposable-site.php tests/Unit/HistoryPageTest.php` | PASS |
| `composer audit --locked` | No vulnerability advisories |
| `npm install --package-lock-only --ignore-scripts` | Created a dependency-free lockfile; no runtime dependency added |
| `npm test`, `npm run build` | PASS, existing JS syntax checks; not browser E2E |
| `npm audit --omit=dev` | Zero vulnerabilities |
| `wp i18n make-pot ...`, `msgmerge --update --backup=none ...`, `msgfmt --check-format ...` | PASS; updated POT and recovery-related Russian strings/MO |
| `npm run plugin-zip` | PASS |
| `LD_PRELOAD=/lib/x86_64-linux-gnu/libwebp.so.7 bash scripts/test-integration.sh` | PASS, WP 7.1/WC 11.1.0, both order stores |
| `PAYKASSA_TEST_WP_VERSION=6.6 PAYKASSA_TEST_WC_VERSION=8.5.2 LD_PRELOAD=/lib/x86_64-linux-gnu/libwebp.so.7 bash scripts/test-integration.sh` | PASS, both order stores |
| `bash -n scripts/package.sh scripts/test-integration.sh`, `git diff --check` | PASS |
| `python3 tools/verify_readme_guard.py` | PASS, all protected files unchanged |

Initial red runs found test ETH registration happening after WooCommerce cached its currency list, invalid restoration of an absent settings option, and reuse of a synthetic transaction ID across storage-mode runs. These were corrected (no assertions disabled). The transaction collision also led to a production event-store binding check and an explicit negative regression. Final runs above contain all fixes.

The additional real Action Scheduler lifecycle test failed on WooCommerce 8.5.2 with **two pending continuations** after the first batch. Its hybrid store does not implement the factory's `save_unique_action()` path, so the `unique` argument alone did not deduplicate the calls from execution and completion hooks. Scheduling now checks existing pending/running jobs under the connection-bound database mutex, retaining Action Scheduler as the scheduler. A zero action ID is logged as failure; scheduling exceptions cannot crash checkout bootstrap. Both version pairs and both order stores passed the unchanged uniqueness assertion after this fix.

## Artifact, security and compatibility

Artifact: `dist/paykassa-2.0.0.zip`, SHA-256 `de53442411501aa006d57230b3c6f53181df423c38d15f67bc5b22f4be2298d6`. Byte comparison matched **46** source/runtime files (src, languages, Blocks asset, entry point, uninstall), including the files installed in both final test sites. ZIP denylist check found no tests, scripts, tools, docs, vendor, node_modules, dist, Git, IDE or npm lockfile. Packaging now excludes the development tools directory and lockfile.

Reviewed logging call sites and ran targeted searches for disabled TLS, raw order post/meta access, deprecated SSL/order-total usage, TODO/FIXME and debug dumps: none found in the production paths searched. A filename-only scan for common private-key/AWS/GitHub-token patterns found no matches; this is not a comprehensive secrets-history scanner. No credentials or real payments were used. Both remote adapters retain fixed origins and TLS verification; history has a bounded response size and strict envelope parsing. Full history bodies/private tokens are not persisted or logged.

No DB schema change: version **3** stays intact, including the prior v2 upgrade. Settings/credentials and existing financial records are preserved. New recovery options are non-autoloaded and new order metadata uses WC CRUD. Deactivation and uninstall stop only PayKassa scheduling; deactivation preserves the cursor/financial data. No new refunds, payouts, saved tokens or recurring-payment claims.

Classic gateway invoice creation and shared backend settlement were exercised. **Browser Classic/Blocks E2E and external sandbox confirmation were not executed in this targeted regression**, so this report is not a release-wide checkout certification. Frontend JS was unchanged. The latest WP/WC installation still emits an upstream WooCommerce early-translation notice before PayKassa is installed; it was not hidden or called a clean debug log. npm also reports an environment-owned `min-release-age` configuration warning, not a failed plugin check. Command-scoped `LD_PRELOAD` avoids the local XAMPP/system WebP conflict without modifying host configuration.

## Files changed

- Added: `src/Infrastructure/DatabaseMutex.php`, `src/PayKassa/Dto/HistoryCandidate.php`, `src/PayKassa/Dto/HistoryPage.php`.
- Changed recovery/provider: `src/Reconciliation/ReconciliationService.php`, `ReconciliationScheduler.php`, `src/PayKassa/ApiClient.php`, `SciClient.php`, `Dto/PaymentEvidence.php`.
- Changed settlement: `src/Webhook/WebhookProcessor.php`, `WebhookEventStore.php`.
- Changed integration/lifecycle: `src/Admin/DiagnosticsPage.php`, `src/Gateway/PayKassaGateway.php`, `paykassa.php`, `uninstall.php`.
- Added tests: `tests/Integration/wp-cli-reconciliation.php`, `tests/fixtures/reconciliation-worker.php`, `tests/Unit/HistoryPageTest.php`.
- Changed tests/build: `tests/Integration/wp-cli-smoke.php`, `tests/fixtures/disposable-site.php`, `scripts/test-integration.sh`, `scripts/package.sh`; added `package-lock.json`.
- Updated `languages/paykassa.pot`, `languages/paykassa-ru_RU.po`, `languages/paykassa-ru_RU.mo`; added this report and `docs/architecture/recovery-decision.md`.
- Existing user changes in `.idea/` were not edited or reverted.

## Recovery/rollback guidance

Disable **Payment recovery** to stop further reconciliation calls; pending cursors and financial events remain. After resolving an API outage, scheduled retries use the same cursor and settlement ledger. Never delete event/transaction data to force a payment retry. Do not enable unattended recovery until PayKassa's live history contract is validated with anonymized fixtures and a controlled live lost-webhook payment. Use database backups for rollback; reverting to an older gateway that lacks the event/order checks is not a safe payment rollback procedure.
