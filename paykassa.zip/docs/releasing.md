# Releasing

1. Run all Composer and npm checks, then inspect the release zip.
2. Install it on a fresh WooCommerce site and an upgrade fixture containing `woocommerce_paykassa_settings` from 1.0.2.
3. Test HPOS, Checkout Block and the legacy callback with mocked SCI verification.
4. Sync the clean payload into WordPress.org SVN `/trunk` (files directly in `trunk`), commit, then `svn copy trunk tags/2.0.0`.

Never put `trunk` inside a tag directory and never include `.git`, development dependencies, tests, IDE data or secrets in the payload.
