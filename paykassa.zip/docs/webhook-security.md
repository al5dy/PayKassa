# Webhook security

Incoming callback fields are not payment evidence. The controller permits only bounded POST requests with a format-checked `private_hash` and technical `order_id`. The raw order ID is used only to locate immutable credential contexts for that order; the retained secret/Test Mode profile must then pass PayKassa SCI verification, and the verified order ID must equal the routing hint. Raw amount, order ID, system and currency are never trusted as settlement facts.

The processor compares provider evidence to an immutable invoice snapshot using decimal strings, reserves the provider transaction in a table with a unique index, and only then invokes `WC_Order::payment_complete()`. Logs use token fingerprints rather than private hashes or secrets.

IP ranges are deliberately not treated as a source of authenticity. TLS verification is enabled for every PayKassa request. Retained SCI secrets are stored only in the non-autoloaded credential-profile option and never appear in order meta, logs, diagnostics or callback responses.
