# Webhook security

Incoming callback fields are not payment evidence. The controller permits only bounded POST requests with a format-checked `private_hash`; it then calls PayKassa SCI verification with the configured merchant credentials. Raw amount, order ID and currency are never trusted.

The processor compares provider evidence to an immutable invoice snapshot using decimal strings, reserves the provider transaction in a table with a unique index, and only then invokes `WC_Order::payment_complete()`. Logs use token fingerprints rather than private hashes or secrets.

IP ranges are deliberately not treated as a source of authenticity. TLS verification is enabled for every PayKassa request.
