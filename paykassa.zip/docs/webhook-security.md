# Webhook security

Incoming callback fields are not payment evidence. The controller permits only bounded POST requests with a format-checked `private_hash` and technical `order_id`. The raw order ID is used only to locate immutable credential contexts for that order; the retained secret/Test Mode profile must then pass PayKassa SCI verification, and the verified order ID must equal the routing hint. Raw amount, order ID, system and currency are never trusted as settlement facts.

The processor compares provider evidence to an immutable invoice snapshot using decimal strings, reserves the provider transaction in a table with a unique index, and only then invokes `WC_Order::payment_complete()`. Logs use token fingerprints rather than private hashes or secrets.

The two POST endpoints are independent verification channels:

- `wc_gateway_paykassa` calls `sci_confirm_order` and requires the verified payment-link hash.
- `wc_gateway_paykassa_transaction` calls Live-only `sci_confirm_transaction_notification`. Its verified DTO has no payment-link hash and uses an explicit unambiguous-match policy; no snapshot value is copied into provider evidence.

Both channels use the same event key based on retained merchant context, environment and provider transaction ID, so the source label (`webhook_invoice` or `webhook_transaction`) cannot create two settleable payments. Verified pending transaction status creates no settlement event. Verified but durably stored retired/ambiguous transaction evidence is acknowledged for manual review. Verification, matching, event storage or settlement failures that are not durable terminal outcomes receive no success acknowledgement.

Browser return endpoints accept GET only and never call SCI, `WebhookProcessor` or `payment_complete()`. Their merchant URLs always use canonical `home_url('/')`; the optional external callback override cannot move them to a tunnel origin where store cookies would be unavailable. Registered orders require the owning logged-in customer (or `manage_woocommerce`); guest authorization is a bounded WooCommerce-session map of order ID to an HMAC of the order key. Invalid ownership receives a generic redirect that contains neither order ID nor order key.

IP ranges are deliberately not treated as a source of authenticity. TLS verification is enabled for every PayKassa request. Retained SCI secrets are stored only in the non-autoloaded credential-profile option and never appear in order meta, logs, diagnostics or callback responses.
