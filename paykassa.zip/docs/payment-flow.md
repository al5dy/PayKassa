# Payment flow

1. WooCommerce creates an order and calls `process_payment`.
2. The plugin validates the selected cryptocurrency/network independently of the order currency. Where needed, it requests a fresh PayKassa Currency API quote and uses decimal-string arithmetic to obtain the SCI crypto amount.
3. SCI creates one hosted invoice using the internal order ID. The immutable snapshot records order amount/currency, payment amount/currency/system and quote context; WooCommerce order money is never changed.
   The durable lifecycle crosses `preparing -> creating` by owner-token CAS immediately before SCI, while a connection-bound database mutex remains held across the remote call. Only pre-provider preparation can be lease-reclaimed, and a stale owner fails the CAS before contacting SCI. A timeout or abandoned remote create becomes `uncertain`; manual release must acquire the same mutex.
4. The customer is redirected only to an HTTPS PayKassa hostname.
5. The legacy WC-API callback submits `private_hash` to SCI verification.
6. The verified response must match the order's original amount/currency and the stored payment-side exact crypto amount, currency and system.
7. A unique transaction reservation is inserted before `payment_complete()`. Only then can WooCommerce reduce stock and settle the order.

Cancelled orders with a later valid payment go to on-hold/manual review; they are acknowledged so PayKassa does not continuously retry, but are never silently fulfilled.

SCI `createOrder` does not document an expiry timestamp or an authoritative lookup for a timed-out create. The plugin therefore stores unknown expiry as `null` and never substitutes quote age as invoice TTL. A merchant can retire a confirmed unusable hosted invoice from the order panel; its immutable snapshot is archived before one replacement is allowed. A verified late payment for the retired invoice is acknowledged and held for manual review, never automatically fulfilled against the replacement. See [the hosted invoice lifecycle decision](architecture/invoice-lifecycle-decision.md).
