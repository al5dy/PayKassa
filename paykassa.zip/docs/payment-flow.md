# Payment flow

1. WooCommerce creates an order and calls `process_payment`.
2. The plugin validates the chosen documented network against the order's saved currency.
3. SCI creates one hosted invoice using the internal order ID. The plugin writes an immutable snapshot and redirect URL through WooCommerce order CRUD.
4. The customer is redirected only to an HTTPS PayKassa hostname.
5. The legacy WC-API callback submits `private_hash` to SCI verification.
6. The verified response must match order ID, exact decimal amount, currency and system in the stored snapshot.
7. A unique transaction reservation is inserted before `payment_complete()`. Only then can WooCommerce reduce stock and settle the order.

Cancelled orders with a later valid payment go to on-hold/manual review; they are acknowledged so PayKassa does not continuously retry, but are never silently fulfilled.
