# 16 — README and Release Metadata Policy

Protected by default:

- root `readme.txt`;
- root `README.md`;
- root `CHANGELOG.md`.

No protected file changes unless user's current task explicitly authorizes exact section/metadata.

“Prepare release”, “bump version”, “update docs” and “make compatible with latest WordPress” do not automatically authorize README edits.

Changelog/version fields are explicit-only.

When authorized, modify only requested section and preserve historical changelog entries unless explicit correction is requested.

Public claims about provider verification, supported currencies, refunds, subscriptions, external service, HPOS/Blocks and privacy must remain truthful and evidence-backed.

`README_BASELINE.sha256` + guard enforce byte identity when no authorization exists.

Never update baseline merely because guard failed.
