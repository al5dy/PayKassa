# 17 — High-Risk Feature Policy

Automated refund, payout, saved payment method and automatic subscription renewal are NOT ordinary feature additions.

They require an explicit design task and provider proof.

A sender blockchain address is not proof of refund ownership/safety.

Do not map PayKassa `sendMoney()` to WooCommerce refund automatically.

Any payout requires explicit destination validation, admin authorization, anti-CSRF, amount/currency/network review, idempotency, confirmation UX, audit trail and strong provider result handling.

Subscription auto-renew requires provider-supported tokenized merchant-initiated recurring semantics. Do not invent tokens.

Manual renewal checkout may use normal gateway if WooCommerce allows.

Never claim these capabilities in readme/UI before implementation/security/recovery tests exist.
