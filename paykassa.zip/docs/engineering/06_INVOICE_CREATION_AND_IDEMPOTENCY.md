# 06 — Invoice Creation and Idempotency

Creating a provider invoice is a non-trivial external side effect.

Per-order durable reservation prevents double invoice creation across double-clicks, retries, multiple PHP workers and checkout refreshes.

Valid active snapshot + trusted redirect may be reused.

Ambiguous provider timeout is special: do not immediately release reservation and retry creation because provider may have created invoice despite client timeout.

Lease expiry/reclaim policy must be explicit and schema-backed.

A lock table/query mismatch is a BLOCKER.

Tests must cover first create, immediate retry, concurrent create, expired lease reclaim, DB insert/update failure, provider timeout, unsafe redirect, snapshot saved but reservation-finalization failed and recovery behavior.

Never create a second invoice merely because redirect URL metadata is missing while immutable evidence indicates an unresolved existing creation.
