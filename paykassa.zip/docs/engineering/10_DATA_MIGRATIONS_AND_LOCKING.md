# 10 — Data, Migrations and Locking

Schema version is separate from plugin version.

Released migration history is immutable; add corrective migration.

`schema_is_valid()` must verify every column/index/engine property required by runtime correctness, including all columns used by lock-reclaim SQL.

Never update schema version until required structures verify.

Migrations are idempotent/retry-safe and preserve 1.x merchant credentials/settings.

Custom tables store minimal non-secret audit/idempotency state.

Locks/leases have explicit state, expiry, reclaim and crash recovery.

Race protection uses DB uniqueness/atomic predicates, not check-then-insert in PHP.

Test fresh install, upgrade from 1.0.2 fixture, repeated migrate, partial schema, missing column/index, expired lease reclaim, DB failure and concurrent migration/lock acquisition.

Do not run expensive DDL every ordinary request once current schema verified.
