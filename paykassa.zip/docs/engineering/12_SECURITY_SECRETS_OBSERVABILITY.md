# 12 — Security, Secrets and Observability

Secrets: merchant password, API password, private hashes/tokens, authorization headers.

Never log/render/export them. Use fingerprints for correlation only.

Admin mutations require capability + nonce + POST + validation. Webhooks do not use nonce; they use provider verification + replay/idempotency controls.

SQL dynamic values are prepared. Table names derive only from internal `$wpdb->prefix` composition.

Late-escape output by context.

No stack traces/provider raw payloads in customer errors.

Woo logger source remains stable (`paykassa`) and context is structured/redacted.

Diagnostics should expose safe version/schema/configuration/last-reconciliation state, not credentials.

Site Health must not perform destructive/payment-changing checks.

Security regression tests cover secret masking, callback malformed token, unsafe redirect, SQL/adversarial identifiers, admin capability/nonce and log redaction.
