# 14 — Reliability and Performance

Checkout/webhook paths must be bounded and deterministic.

No PayKassa remote calls on ordinary frontend/admin page views.

Provider requests have finite timeout. Customer-facing checkout receives safe failure without PHP fatal.

Webhook processing does only necessary verification/reservation/settlement/ack work.

DB queries use indexes for event key, provider context, order/status and lease recovery.

Reconciliation is bounded and scheduled, not full-table polling.

Do not cache mutable payment evidence incorrectly. Stable provider capability/network metadata may be cached with invalidation policy.

Lease expiry values are part of correctness; test clock boundaries.

Performance testing should include webhook burst duplicates, many historical event rows and pending-order reconciliation volumes.

A performance optimization may never weaken idempotency or verification.
