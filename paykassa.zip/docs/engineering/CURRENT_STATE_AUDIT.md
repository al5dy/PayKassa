# Current PayKassa Snapshot Audit — 2026-09-10

## Strong existing foundations

- Version 2.0.0 rewrite.
- 36/36 files under `src/` use `declare(strict_types=1)`.
- PHP 8.1+, WordPress 6.6+, WooCommerce 8.5+ declared.
- HPOS and Checkout Blocks compatibility declared.
- WooCommerce CRUD is used for order access in reviewed payment paths.
- Immutable `PaymentSnapshot` exists.
- Exact decimal-string comparison exists.
- Payment state object exists.
- Durable webhook event table and invoice lock table exist.
- Redirect host validator exists.
- PayKassa transport uses WordPress HTTP/TLS instead of legacy cURL wrapper.
- Redacted/fingerprinted logging design exists.
- Legacy settings and callback URL preservation are explicitly considered.
- Package builder excludes development files.

## Critical current repository findings

### 1. `WebhookProcessor.php` is deleted from the working source tree

The supplied Git working tree reports:

```text
D src/Webhook/WebhookProcessor.php
```

`WebhookController` still instantiates `WebhookProcessor`.

The existing `dist/paykassa-2.0.0.zip` contains an older/stale copy of `WebhookProcessor.php`, which means source and release artifact are currently inconsistent.

**Risk:** rebuilding a release from the current working tree can omit a callback-critical runtime class and cause fatal failure during verified callback processing.

**Required:** restore/reconcile the processor source and add source/package parity + callback smoke gate.

### 2. Invoice lock schema/runtime mismatch

`InvoiceLockStore::acquire()` reclaims an expired lease using:

```text
attempts = attempts + 1
```

but `Installer`'s `paykassa_invoice_locks` table definition in the supplied source does not create an `attempts` column.

`schema_is_valid()` also does not validate required columns of the invoice-lock table beyond its existence.

**Risk:** expired invoice-creation lease reclaim can fail at SQL level, preventing safe recovery after a crashed/ambiguous invoice creation.

**Required:** correct schema through a versioned migration, validate required lock-table columns/indexes, and add expired-lease integration test.

## Test/CI gap

- Only 5 `*Test.php` unit tests are selected by current `phpunit.xml.dist`.
- Repository contains `tests/Integration/wp-cli-smoke.php` and `wp-cli-upgrade-smoke.php`, but they are not part of PHPUnit config.
- GitHub Actions runs `composer test`, which therefore exercises the unit suite, not these real WooCommerce smoke scripts.
- The integration smoke script references the currently deleted `WebhookProcessor`, demonstrating why package/source/runtime integration gates are needed.

**Assessment:** good unit foundation, insufficient payment-release proof.

## Static-analysis gap

- PHPStan current level: 5.
- PHPCS ruleset is primarily PSR-12; the handbook target is stronger WordPress/WooCommerce-aware quality enforcement without lowering compatibility.

## Current release metadata

- Root `readme.txt` says `Tested up to: 6.9` while current stable WordPress as of audit is 7.1.
- WooCommerce metadata says tested up to 11.1, matching current WooCommerce 11.1.x line.

Protected README policy means this mismatch must be reported, not silently edited, unless the user explicitly authorizes README metadata changes.

## Current implementation readiness

Because callback-critical source/package drift and lock-schema mismatch exist, the supplied working tree is **not production 10/10** today.

The handbook is designed to make these classes of defects impossible to approve silently.
