# 05 — Webhook and Settlement Security

Raw incoming fields are untrusted. `private_hash` is only a token passed to PayKassa verification, not itself sufficient payment evidence.

Callback handler bounds method/size/format, performs server verification, validates evidence against snapshot, reserves provider transaction durably, then settles.

Event dedup key must include enough merchant/environment context to avoid cross-context collisions without leaking secrets.

Different DB failures must never be misclassified as harmless duplicates.

Settlement ordering matters: durable unique reservation must exist before `payment_complete()` so duplicate/concurrent delivery cannot double fulfil.

Event state transitions and lease reclaim are atomic/tested.

If settlement writes succeed but final event bookkeeping fails, retry behavior must not cause a second fulfilment. Tests must model crash points around each durable step.

Cancelled order + valid late payment: acknowledge per provider protocol if current policy requires, move to on-hold/manual review, never silently fulfil or discard funds.

Mismatch: never paid; record safe conflict/manual review and redacted diagnostic.

Webhook endpoint never exposes trace, token or merchant secret.
