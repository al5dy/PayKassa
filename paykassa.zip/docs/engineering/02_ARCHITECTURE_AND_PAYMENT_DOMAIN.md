# 02 — Architecture and Payment Domain

Keep provider, WooCommerce, HTTP and admin concerns outside core payment decisions.

Core domain concepts include immutable payment snapshot, payment state, payment evidence, invoice reservation and event reservation.

State transitions must be explicit and tested. Paid/conflicted terminal semantics must not regress accidentally.

Controllers parse/verify/map; services decide; repositories persist; admin renders.

Provider DTOs must be typed and validated before domain use.

Do not use service locator/global mutable registries. Constructor injection is preferred for high-risk collaborators so tests can exercise failures.

Public hooks (`paykassa_payment_created`, `paykassa_payment_confirmed`, `paykassa_payment_conflict`) are compatibility-sensitive once documented/used. Stable parameter semantics and timing require tests.
