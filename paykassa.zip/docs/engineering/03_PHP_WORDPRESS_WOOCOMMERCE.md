# 03 — PHP, WordPress and WooCommerce

All project-owned runtime PHP uses `declare(strict_types=1);`, typed parameters/returns/properties and PHPStan-visible collection shapes.

Current minimum is PHP 8.1 unless explicitly changed. Do not use syntax above declared minimum.

Raise PHPStan beyond current level 5 toward maximum practical strictness; never lower it for a patch.

Use WooCommerce CRUD for orders. Do not read/write Woo orders with post/meta APIs or direct post tables.

Use internal Woo order ID for correlation; displayed order number is presentation only.

Use WordPress HTTP, enqueue, options, i18n, nonce/capability and filesystem/URL APIs.

Do not hard-code `wp_`, site URL or writable plugin path assumptions.

Plugin bootstrap remains small. Runtime custom autoloader is an intentional packaging choice until explicit architecture task changes it.

HPOS compatibility declaration must reflect real tests, not aspiration.
