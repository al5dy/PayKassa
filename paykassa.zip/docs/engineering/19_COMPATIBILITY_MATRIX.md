# 19 — Compatibility Matrix

Current minimum contract: PHP 8.1+, WordPress 6.6+, WooCommerce 8.5+ unless explicitly changed.

Release tests include minimum and latest stable. As of 2026-09-10: WordPress 7.1; WooCommerce 11.1.x.

WooCommerce:

- HPOS mandatory;
- Checkout Blocks mandatory;
- Classic Checkout mandatory;
- guest checkout/order-pay retry exercised;
- authoritative order CRUD only.

Provider directions are capability-reviewed; unknown currency/network combination is unavailable.

TLS required.

Production runtime must not require Composer/npm.

If a future WooCommerce version removes legacy order store assumptions, compatibility policy may intentionally change after tests/explicit release decision.

Do not update protected readme `Tested up to`/minimum metadata without explicit user authorization even when tests prove a newer version.
