# 18 — Review Playbook

Before coding ask:

- Can this mark an order paid?
- Can it create more than one provider invoice?
- What exact evidence is trusted?
- Which snapshot fields must match?
- What if request is duplicated/concurrent?
- What if DB fails between durable steps?
- What if provider times out ambiguously?
- Could stock/fulfilment execute twice?
- Does HPOS/Blocks/classic behavior change?
- Are secrets/logs affected?
- Does upgrade preserve merchant config?
- Is README protected?

BLOCKER: false settlement, duplicate fulfilment, secret leak, missing runtime file, schema/runtime mismatch, unsafe retry, broken upgrade.

MAJOR: missing concurrency/integration tests, state-machine inconsistency, provider-contract assumption, HPOS/Blocks regression, dangerous diagnostics.

Completion report must contain exact commands/results and final package smoke. No test result may be claimed without execution.
