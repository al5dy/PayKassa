# 01 — Engineering Constitution

PayKassa is payment infrastructure. Optimize for correctness, financial integrity, auditability, safe failure, backward compatibility, maintainability and verifiable behavior.

Priority:

1. Never falsely mark unpaid money as paid.
2. Never duplicate settlement/stock effects.
3. Preserve immutable evidence/history.
4. Prefer explicit manual review over guessing.
5. Preserve WooCommerce/provider compatibility.
6. Keep secrets private.
7. Keep failure diagnosable.
8. Keep code strongly typed/testable.

A professional change defines trust source, state transition, retry semantics, concurrency semantics, failure state and evidence tests.

Do not introduce abstraction for ceremony. Do not rewrite unrelated code in payment patches.

Architecture changes to provider contract, settlement model, persistence, compatibility baseline, refund/payout support or public hooks require an ADR.

Technical debt cannot defer payment verification, idempotency, migration safety or critical tests.
