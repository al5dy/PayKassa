# 13 — Testing and Quality

Payment code requires more than unit tests.

## Unit

Keep fast tests for Decimal, PaymentSnapshot, PaymentState, registry, redirect validation, provider DTO validation and pure policies.

## Real WordPress/WooCommerce integration

Required for release-critical behavior:

- plugin activation/deactivation;
- schema install/upgrade;
- gateway registration;
- settings/secret preservation;
- HPOS order creation/meta;
- Classic Checkout;
- Checkout Blocks registration/data;
- invoice create/reuse;
- server-verified callback settlement;
- duplicate/concurrent callback;
- late cancelled payment;
- migration from 1.0.2.

Existing WP-CLI smoke scripts must be automated in CI or replaced by equivalent CI integration tests. A script not executed in CI is not a gate.

## Concurrency/crash tests

Use real DB/process concurrency for invoice reservation and webhook reservation. Inject crash/failure before/after reservation, order save, `payment_complete()` and event finish.

## Property-based/fuzz

Decimal equality/normalization, token parsing, provider response validation and state transitions should receive generated/adversarial boundary cases.

## Fault injection

Simulate HTTP timeout, 429/5xx, malformed JSON, DB write failure, lock timeout, missing schema column, provider mismatch, invalid redirect and worker crash.

## Browser/E2E

Classic + Blocks, guest, order-pay retry, network selector, gateway unavailable, failed invoice, successful redirect and safe errors.

Use mocked/sandbox provider transport—never real merchant secrets in CI.

## Mutation testing

High-value targets: amount comparison, snapshot matching, terminal state transitions, redirect host validation, duplicate detection and manual-review branches.

## Static analysis

Run PHP syntax, PHPCS/WPCS/PHPCompatibility as configured, PHPStan progressively to max practical strictness and JS checks.

## Coverage

High branch coverage expected for settlement/idempotency/money/state logic. Coverage without concurrency/integration proof is insufficient.

## Flakiness

No arbitrary sleep/retry-until-green. Flaky payment test is a defect.
