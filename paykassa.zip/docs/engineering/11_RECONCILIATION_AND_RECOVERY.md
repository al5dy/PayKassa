# 11 — Reconciliation and Recovery

Reconciliation exists to recover visibility/eligible payments safely, not to weaken verification.

Use Action Scheduler/WooCommerce scheduling; do not create competing scheduler.

Jobs are unique where appropriate, bounded, locked, retry-safe and back off on provider failures.

Never scan all historical orders repeatedly. Query bounded pending PayKassa candidates.

Provider history data may settle only if its documented semantics provide evidence equivalent to settlement policy. Otherwise use it only to flag/manual-review or trigger stronger verification.

Do not infer paid state from ambiguous history record.

Persist last successful/error diagnostic without secrets.

Test overlapping scheduler executions, provider outage, malformed history, duplicate recovery result, order already paid, cancelled order, credentials missing and disabled reconciliation.
