# 07 — WooCommerce Order Lifecycle

WooCommerce owns order status, stock and fulfilment lifecycle.

Use `payment_complete(transaction_id)` only after verified matching evidence and durable dedup reservation.

Do not call manual stock reduction in parallel with standard payment lifecycle.

Test paid statuses under configured WooCommerce behavior rather than hard-coding only `processing`.

Never regress an already paid order due to duplicate callback.

Cancelled/failed/refunded/on-hold cases need explicit transition policy.

Payment method identity must be verified before settlement so a PayKassa callback cannot settle an order paid through another gateway.

HPOS: use Woo CRUD/meta APIs and test authoritative HPOS store. If legacy CPT store remains supported, test both until minimum WooCommerce policy legitimately drops it.

Legacy gateway ID/settings option/callback URL are backward-compatibility contracts for upgrades.
