# 09 — PayKassa Provider API and Transport

Provider semantics come from reviewed current documentation/source. Repository API reference files are evidence, not automatically executable truth forever; changes require re-verification.

Use project-owned adapters and typed DTOs.

WordPress HTTP transport must keep TLS verification enabled, finite connect/overall timeout and bounded response size/JSON parsing.

Do not blindly retry non-idempotent invoice creation after ambiguous timeout.

Validate provider success/error envelopes and required fields strictly.

Redirect URL allowlist requires HTTPS and exact reviewed PayKassa host/subdomain policy; reject userinfo, malformed ports and deceptive suffixes.

Do not dynamically download/execute vendor PHP.

Payment-system registry/fallback must be reviewed against current provider directions. Unknown network is unsupported, not guessed.

Contract fixtures should include malformed JSON, HTTP failure, provider `error=true`, missing fields, wrong type, unknown system/currency and oversized responses.
