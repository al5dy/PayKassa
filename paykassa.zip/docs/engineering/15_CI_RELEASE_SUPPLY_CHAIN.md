# 15 — CI, Release and Supply Chain

Target release gates:

1. `composer validate --strict`;
2. install locked dependencies;
3. PHP syntax;
4. PHPCS/WPCS/PHPCompatibility policy;
5. PHPStan;
6. unit tests;
7. real WordPress/WooCommerce integration tests;
8. npm/JS check;
9. package build;
10. source/package parity;
11. dependency advisories;
12. WordPress Plugin Check where distribution-target applicable;
13. final ZIP install/activate smoke;
14. Classic + Blocks payment smoke with mocked provider;
15. README guard.

Current CI's five unit tests are not enough to approve a payment release.

Test runtime matrix includes declared minimum PHP/WP/Woo and latest stable. As of 2026-09-10 latest stable is WordPress 7.1 and WooCommerce 11.1.x.

Final ZIP must contain every runtime class referenced by source and must not rely on stale `dist/` contents.

Build from clean working tree/tag. Fail if tracked source deletion differs from packaged runtime unexpectedly.

Production ZIP excludes `.git`, IDE, tests, docs/dev references as packaging policy defines, secrets, node_modules and development vendor dependencies.

Dependency additions require maintenance/license/security/runtime review.

Never use GitHub source ZIP as WordPress release unless package policy explicitly makes it equivalent.
