# PayKassa Engineering Handbook

The root `AGENTS.md` contains high-salience hard rules and routes agents to these detailed chapters.

**MUST / MUST NOT / REQUIRED** are hard requirements. **SHOULD** is a strong default. **BLOCKER** means work cannot be considered complete.

The handbook scores the engineering policy system. `CURRENT_STATE_AUDIT.md` separately records the actual supplied repository state; the current implementation is not automatically 10/10 just because policy is.
