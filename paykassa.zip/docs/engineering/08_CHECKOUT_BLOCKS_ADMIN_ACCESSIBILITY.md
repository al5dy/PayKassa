# 08 — Checkout, Blocks, Admin and Accessibility

Classic Checkout and Checkout Blocks share backend payment domain logic.

Do not implement Blocks support via DOM scraping. Use supported WooCommerce Blocks registration/data APIs.

Blocks data exposed to browser must contain only public checkout information, never secrets.

Checkout UI validates network selection server-side regardless of client validation.

Frontend assets load only where needed; no site-wide payment bundle pollution.

Admin uses WooCommerce/WordPress-native settings and tightly scoped custom UI.

Secret controls render blank/masked and preserve stored secret on intentional blank save.

Order diagnostics/meta box must redact secrets/tokens and clearly distinguish invoice created, awaiting, paid, conflicted/manual review.

Accessibility target: WCAG 2.2 AA behavior for plugin-owned controls—labels, keyboard, visible focus, accessible status/errors, contrast.

Browser E2E must cover classic, Blocks, guest checkout, order-pay/retry and gateway unavailable currency/network cases.
