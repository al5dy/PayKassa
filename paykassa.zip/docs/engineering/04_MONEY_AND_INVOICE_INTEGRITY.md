# 04 — Money and Invoice Integrity

Never compare crypto/payment amounts with float equality.

Canonical decimal-string comparison must reject scientific notation/negative/invalid forms unless provider contract explicitly permits them.

Property-test normalization/equality at precision boundaries and very large/small supported values.

Immutable snapshot captures order ID, order currency/amount, provider system/currency, invoice/link identity, environment, merchant context, mode and creation/expiry semantics needed for future verification.

A callback must match snapshot exactly under documented normalization.

Do not validate old invoice against today's store currency, total, enabled networks or credentials when snapshot/context intentionally freezes them.

Do not invent exchange rates. If provider API does not establish a safe quote/conversion contract, hide/reject unsupported fiat/currency paths.

Currency and network are separate dimensions; multi-network assets such as USDT require exact network/system validation.
