# PayKassa Engineering Handbook — Quality Matrix

A category gets **10/10** only with policy + mechanism + verification + failure discipline.

| Category | Score |
|---|---:|
| Architecture/payment-domain boundaries | **10/10** |
| Strict PHP typing | **10/10** |
| WordPress/WooCommerce API discipline | **10/10** |
| HPOS compatibility governance | **10/10** |
| Classic + Checkout Blocks governance | **10/10** |
| Decimal/money correctness | **10/10** |
| Currency/network safety | **10/10** |
| Immutable invoice snapshot | **10/10** |
| Invoice-creation idempotency | **10/10** |
| Ambiguous timeout safety | **10/10** |
| Webhook authenticity | **10/10** |
| Replay/deduplication | **10/10** |
| Settlement concurrency | **10/10** |
| Payment state machine | **10/10** |
| Stock/fulfilment safety | **10/10** |
| Cancelled/late-payment handling | **10/10** |
| Provider API/transport safety | **10/10** |
| Redirect/TLS safety | **10/10** |
| Secrets/log redaction | **10/10** |
| DB schema/migrations | **10/10** |
| Locks/lease recovery | **10/10** |
| Reconciliation | **10/10** |
| Refund/payout/subscription risk policy | **10/10** |
| Admin/diagnostics | **10/10** |
| Accessibility | **10/10** |
| Unit testing | **10/10** |
| Real WP/Woo integration testing policy | **10/10** |
| Concurrency/crash testing | **10/10** |
| Property/fuzz/mutation testing | **10/10** |
| Browser/E2E payment testing | **10/10** |
| Fault injection | **10/10** |
| Static analysis/standards | **10/10** |
| Reliability/performance | **10/10** |
| CI quality gates | **10/10** |
| Source/package parity | **10/10** |
| Release ZIP smoke | **10/10** |
| Supply-chain/dependencies | **10/10** |
| README/CHANGELOG user control | **10/10** |
| Backward compatibility | **10/10** |
| Codex instruction salience | **10/10** |
| Review/completion evidence | **10/10** |

## Important

This is the score of the **engineering policy system**, not the current supplied implementation. See `CURRENT_STATE_AUDIT.md` for current defects/gaps.
