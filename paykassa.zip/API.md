API | Get Balance of merchant
Method name: api_get_shop_balance. Get balance of merchant.

POST
https://paykassa.app/api/0.9/index.php
Parameter
Field	Type	Description
func	String	
Method name, must be: api_get_shop_balance

Default value: api_get_shop_balance

api_id	String	
API ID

api_key	String	
API Password

shop_id	String	
Merchant ID

Success 200
Field	Type	Description
error	Boolean	
false - Success

Information	String	
message

data	Object	
Extradata - cointain pairs key system name and currency name(ex. BinanceCoin BNB => "binancecoin_bnb") from https://coinmarketcap.com in lowercase, value current balance

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Balance store successfully received.",
     "data": {
         "bitcoin_btc": "6.19148781",
         "ethereum_eth": "16.65759653",
         "litecoin_ltc": "10.81039547",
         "dogecoin_doge": "14055330.30324031",
         "dash_dash": "62.08654262",
         "bitcoincash_bch": "230.00235701",
         "ripple_xrp": "130977.938830",
         "tron_trx": "15003.120000",
         "stellar_xlm": "150325.0002350",
         "binancecoin_bnb": "1525.003350",
         "tron_trc20_usdt": "100.0000",
         "binancesmartchain_bep20_usdt": "100.0000",
         "ethereum_erc20_usdt": "100.0000",
         "binancesmartchain_bep20_usdc": "100.0000",
         "binancesmartchain_bep20_ada": "100.0000",
         "binancesmartchain_bep20_eos": "30.0000",
         "binancesmartchain_bep20_btc": "0.002355",
         "binancesmartchain_bep20_eth": "2.2342356",
         "binancesmartchain_bep20_doge": "1100300.003423400"
     }
}
Error 4xx
Name	Type	Description
error	Boolean	
true - Fail

message	String	
Error description

data	Object	
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Access is denied. Error code: 10.",
     "data": {}
 }


 API | Get Balance of merchant
Method name: api_get_shop_balance. Get balance of merchant.

POST
https://paykassa.app/api/0.9/index.php
Parameter
Field     Type Description
func String    
Method name, must be: api_get_shop_balance

Default value: api_get_shop_balance

api_id    String    
API ID

api_key   String    
API Password

shop_id   String    
Merchant ID

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata - cointain pairs key system name and currency name(ex. BinanceCoin BNB => "binancecoin_bnb") from https://coinmarketcap.com in lowercase, value current balance

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Balance store successfully received.",
     "data": {
         "bitcoin_btc": "6.19148781",
         "ethereum_eth": "16.65759653",
         "litecoin_ltc": "10.81039547",
         "dogecoin_doge": "14055330.30324031",
         "dash_dash": "62.08654262",
         "bitcoincash_bch": "230.00235701",
         "ripple_xrp": "130977.938830",
         "tron_trx": "15003.120000",
         "stellar_xlm": "150325.0002350",
         "binancecoin_bnb": "1525.003350",
         "tron_trc20_usdt": "100.0000",
         "binancesmartchain_bep20_usdt": "100.0000",
         "ethereum_erc20_usdt": "100.0000",
         "binancesmartchain_bep20_usdc": "100.0000",
         "binancesmartchain_bep20_ada": "100.0000",
         "binancesmartchain_bep20_eos": "30.0000",
         "binancesmartchain_bep20_btc": "0.002355",
         "binancesmartchain_bep20_eth": "2.2342356",
         "binancesmartchain_bep20_doge": "1100300.003423400"
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Access is denied. Error code: 10.",
     "data": {}
 }
API | Get currency rate for pair
Method name: api_currency_rate. Get currency rate for pair. Attention!!! Instead of the paykassa.pro domain, you should use the currency.paykassa.pro subdomain.

GET/POST
https://currency.paykassa.pro/index.php
Parameter
Field     Type Description
currency_in    String    
From currency

Allowed values: USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, XRP, TRX, XLM, BNB, USDT, ADA, EOS, GBP, EUR, USDC, TON, SHIB

currency_out   String    
To currency

Allowed values: USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, XRP, TRX, XLM, BNB, USDT, ADA, EOS, GBP, EUR, USDC, TON, SHIB

Success 200
Field     Type Description
error     Boolean   
false - Success

message   String    
Success message

data Object    
Extradata

  value   String    
Current rate currency_in / currency_out

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Ok",
     "data": {
         "value": "11873.180000000000"
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Wrong currency_out!",
     "data": {}
 }
API | Get txids of invoices
Method name: api_get_shop_txids. Get balance of merchant.

POST
https://paykassa.app/api/0.9/index.php
Parameter
Field     Type Description
func String    
Method name, must be: api_get_shop_txids

Default value: api_get_shop_txids

api_id    String    
API ID

api_key   String    
API Password

shop_id   String    
Merchant ID

invoices  Array     
Invoice IDs

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata - key - invoice_id (string) value - array (txids as string)

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Ok",
      "data": {
         "37202989": [
             "3789588db700d2d43b1f4933d9917e0956de5635a8304dcdd36d58e3e2a91796"
         ],
         "374118633": [
             "5b70f95fa238822e4c2f62e3755c5d41e0fe024df8d865b001bc1cfd99763808"
         ],
         "3741186333": [
             "fbe747ff4f84d8e934fc78c3b89e6983a60bdaef1bb0948c973658c4609de6be"
         ]
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Access is denied. Error code: 10.",
     "data": {}
 }
API | Instant payment
Method name: api_payment. This is an instant payment method designed for executing automatic mass payments from your merchant account.

POST
https://paykassa.app/api/0.9/index.php
Parameter
Field     Type Description
func String    
A method name, must be: api_payment

Default value: api_payment

api_id    String    
An API ID

api_key   String    
An API Password

shop_id   String    
An Merchant ID

amount    String    
The amount that will be sent (transferred to the recipient)"

currency  String    
An currency

Allowed values: BTC, ETH, LTC, DOGE, DASH, BCH, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB, TON

system    String    
An system ID

Allowed values: 11-BitCoin(BTC), 12-Ethereum(ETH), 14-Litecoin(LTC), 15-Dogecoin(DOGE), 16-Dash(DASH), 18-BitcoinCash(BCH), 33-TON(TON, USDT), 22-Ripple(XRP), 27-TRON(TRX), 28-Stellar(XLM), 29-BinanceCoin(BNB), 30-TRON_TRC20(USDT), 31-BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), 32-Ethereum_ERC20(USDT, USDC, SHIB)

number    String    
An address of a recipient, ex. 3LPnTCZFWdHRUC3imeyPsFEeAV68Qkpw9E

tag  Number    
A tag of Ripple or Stellar if the one is required

Allowed values: 1, 2, ...

priority  String    
The parameter influences the order in which a transaction is included into a block (BitCoin, Litecoin, Dogecoin, Dash, BitcoinCash)

Default value: medium

Allowed values: low, medium, high

test String    
Turn on/off a test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

message   String    
An information of a message

  data    Object    
An extra data

  shop_id String    
Merchant ID of Paykassa

  transaction  String    
Transaction number of Paykassa.pro

  payment_id   String    
Transaction number of payment system

  txid    String    
Transaction number of CoinNetwork

  amount  String    
Amount of the payment charge from balance

  amount_pay   String    
Amount of the payment to balance target wallet

  system  String    
Name of system(BitCoin(BTC), Ethereum(ETH), Litecoin(LTC), Dogecoin(DOGE), Dash(DASH), BitcoinCash(BCH), TON(TON, USDT), Ripple(XRP), TRON(TRX), Stellar(XLM), BinanceCoin(BNB), TRON_TRC20(USDT), BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), Ethereum_ERC20(USDT,USDC,SHIB)

  currency     String    
Name of currency(BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB)

  number  String    
Address where you sent the funds

  shop_commission_percent     String    
Fee % value

  shop_commission_amount String    
Fee fix value

  paid_commission   String    
Who paid commission

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Data has been successfully received.",
     "data": {
         "shop_id": "123", // id merchant from which you made the payment, example 122
         "transaction": "130236", // transaction number of the payment, example 130236
         "payment_id": "478937139", // transaction number of the payment system, example 478937139
         "txid": "70d6dc6841782c6efd8deac4b44d9cc3338fda7af38043dd47d7cbad7e84d5dd" // txid 70d6dc6841782c6efd8deac4b44d9cc3338fda7af38043dd47d7cbad7e84d5dd
         "amount": "1.01", // the amount of the payment, how much was written off from the balance store 0.42
         "amount_pay": "1.0306", // the amount of the payment, as it is the user, example: 0.41
         "system": "BitCoin", // system, example: BitCoin(BTC), Ethereum(ETH), Litecoin(LTC), Dogecoin(DOGE), Dash(DASH), BitcoinCash(BCH), TON(TON, USDT), Ripple(XRP), TRON(TRX), Stellar(XLM), BinanceCoin(BNB), TRON_TRC20(USDT), BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), Ethereum_ERC20(USDT,USDC,SHIB)
         "currency": "BTC", // the currency of payment, for example: USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, XLM, BNB, USDT, USDC, ADA, EOS, SHIB
         "number": "3LaKdUrPfVyZeEVYpZei3HwjqQj5AHHTCE", // the address where you sent the funds
         "shop_comission_percent": "1.5", // the transfer fee percentage, example: 1.5
         "shop_comission_amount": "1.0", // the transfer fee amount, example: 1.00
         "paid_commission": "shop" // who paid for the commission, for example: shop
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "There is not enough money on the account. Error code: 58.",
     "data": {}
 }


 API | Instant payment
Method name: api_payment. This is an instant payment method designed for executing automatic mass payments from your merchant account.

POST
https://paykassa.app/api/0.9/index.php
Parameter
Field     Type Description
func String    
A method name, must be: api_payment

Default value: api_payment

api_id    String    
An API ID

api_key   String    
An API Password

shop_id   String    
An Merchant ID

amount    String    
The amount that will be sent (transferred to the recipient)"

currency  String    
An currency

Allowed values: BTC, ETH, LTC, DOGE, DASH, BCH, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB, TON

system    String    
An system ID

Allowed values: 11-BitCoin(BTC), 12-Ethereum(ETH), 14-Litecoin(LTC), 15-Dogecoin(DOGE), 16-Dash(DASH), 18-BitcoinCash(BCH), 33-TON(TON, USDT), 22-Ripple(XRP), 27-TRON(TRX), 28-Stellar(XLM), 29-BinanceCoin(BNB), 30-TRON_TRC20(USDT), 31-BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), 32-Ethereum_ERC20(USDT, USDC, SHIB)

number    String    
An address of a recipient, ex. 3LPnTCZFWdHRUC3imeyPsFEeAV68Qkpw9E

tag  Number    
A tag of Ripple or Stellar if the one is required

Allowed values: 1, 2, ...

priority  String    
The parameter influences the order in which a transaction is included into a block (BitCoin, Litecoin, Dogecoin, Dash, BitcoinCash)

Default value: medium

Allowed values: low, medium, high

test String    
Turn on/off a test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

message   String    
An information of a message

  data    Object    
An extra data

  shop_id String    
Merchant ID of Paykassa

  transaction  String    
Transaction number of Paykassa.pro

  payment_id   String    
Transaction number of payment system

  txid    String    
Transaction number of CoinNetwork

  amount  String    
Amount of the payment charge from balance

  amount_pay   String    
Amount of the payment to balance target wallet

  system  String    
Name of system(BitCoin(BTC), Ethereum(ETH), Litecoin(LTC), Dogecoin(DOGE), Dash(DASH), BitcoinCash(BCH), TON(TON, USDT), Ripple(XRP), TRON(TRX), Stellar(XLM), BinanceCoin(BNB), TRON_TRC20(USDT), BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), Ethereum_ERC20(USDT,USDC,SHIB)

  currency     String    
Name of currency(BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB)

  number  String    
Address where you sent the funds

  shop_commission_percent     String    
Fee % value

  shop_commission_amount String    
Fee fix value

  paid_commission   String    
Who paid commission

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Data has been successfully received.",
     "data": {
         "shop_id": "123", // id merchant from which you made the payment, example 122
         "transaction": "130236", // transaction number of the payment, example 130236
         "payment_id": "478937139", // transaction number of the payment system, example 478937139
         "txid": "70d6dc6841782c6efd8deac4b44d9cc3338fda7af38043dd47d7cbad7e84d5dd" // txid 70d6dc6841782c6efd8deac4b44d9cc3338fda7af38043dd47d7cbad7e84d5dd
         "amount": "1.01", // the amount of the payment, how much was written off from the balance store 0.42
         "amount_pay": "1.0306", // the amount of the payment, as it is the user, example: 0.41
         "system": "BitCoin", // system, example: BitCoin(BTC), Ethereum(ETH), Litecoin(LTC), Dogecoin(DOGE), Dash(DASH), BitcoinCash(BCH), TON(TON, USDT), Ripple(XRP), TRON(TRX), Stellar(XLM), BinanceCoin(BNB), TRON_TRC20(USDT), BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), Ethereum_ERC20(USDT,USDC,SHIB)
         "currency": "BTC", // the currency of payment, for example: USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, XLM, BNB, USDT, USDC, ADA, EOS, SHIB
         "number": "3LaKdUrPfVyZeEVYpZei3HwjqQj5AHHTCE", // the address where you sent the funds
         "shop_comission_percent": "1.5", // the transfer fee percentage, example: 1.5
         "shop_comission_amount": "1.0", // the transfer fee amount, example: 1.00
         "paid_commission": "shop" // who paid for the commission, for example: shop
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "There is not enough money on the account. Error code: 58.",
     "data": {}
 }



 API | Get txids of invoices
Method name: api_get_shop_txids. Get balance of merchant.

POST
https://paykassa.app/api/0.9/index.php
Parameter
Field     Type Description
func String    
Method name, must be: api_get_shop_txids

Default value: api_get_shop_txids

api_id    String    
API ID

api_key   String    
API Password

shop_id   String    
Merchant ID

invoices  Array     
Invoice IDs

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata - key - invoice_id (string) value - array (txids as string)

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Ok",
      "data": {
         "37202989": [
             "3789588db700d2d43b1f4933d9917e0956de5635a8304dcdd36d58e3e2a91796"
         ],
         "374118633": [
             "5b70f95fa238822e4c2f62e3755c5d41e0fe024df8d865b001bc1cfd99763808"
         ],
         "3741186333": [
             "fbe747ff4f84d8e934fc78c3b89e6983a60bdaef1bb0948c973658c4609de6be"
         ]
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Access is denied. Error code: 10.",
     "data": {}
 }


API | Get currency rate for pair
Method name: api_currency_rate. Get currency rate for pair. Attention!!! Instead of the paykassa.pro domain, you should use the currency.paykassa.pro subdomain.

GET/POST
https://currency.paykassa.pro/index.php
Parameter
Field     Type Description
currency_in    String    
From currency

Allowed values: USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, XRP, TRX, XLM, BNB, USDT, ADA, EOS, GBP, EUR, USDC, TON, SHIB

currency_out   String    
To currency

Allowed values: USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, XRP, TRX, XLM, BNB, USDT, ADA, EOS, GBP, EUR, USDC, TON, SHIB

Success 200
Field     Type Description
error     Boolean   
false - Success

message   String    
Success message

data Object    
Extradata

  value   String    
Current rate currency_in / currency_out

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Ok",
     "data": {
         "value": "11873.180000000000"
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Wrong currency_out!",
     "data": {}
 }

 SCI
SCI | Check payment(for IPN)
Method name: sci_confirm_order. This method is used in the handler of the payment receipt. The handler is called automatically by the PayKassa.pro service until the script responds <order_id>|success (maximum 5 times, otherwise you need to send a notification manually from the profile). The payment processor is called automatically from the notification servers 54.37.60.196, 51.91.80.241, 138.68.137.53. These IPs need to be added to the exceptions of your FireWall or DDoS filter, so that notifications go smoothly. The current list of IP can be obtained in text format via the URL: https://paykassa.pro/ips.txt or in JSON format: https://paykassa.pro/ips.php. The server sends a POST request, in which it passes a private_hash (random string), system (the name of the payment system or currency), currency (abbreviated currency name), order_id (payment id in your project). Next you must pass the received private_hash in the SCI request to the sci_confirm_order method, which will allow you to check whether the payment was successful.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_confirm_order

Default value: sci_confirm_order

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

private_hash   String    
From POST request

test Boolean   
Turn on test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  transaction  String    
Invoice ID in Paykassa

  shop_id String    
Merchant ID in Paykassa

  order_id     String    
Payment ID in your merchant

  amount  String    
Amount to be received

  currency     String    
Name of currency

  system  String    
Name of system

  address String    
Destination address

  tag     String    
Tag for Ripple and Stellar

  hash    String    
Uuid of payment link

  partial String    
Arbitrary amount payment identifier

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Payment successfully verified",
     "data": {
         "transaction": "96401", // transaction number in the system paykassa: 96401
         "shop_id": "123", // Merchant ID 123
         "order_id": "12345",  // unique numeric identifier of the payment in your merchant, example: 150800
         "amount": "1.01", // invoice amount example: 1.01
         "currency": "BTC", // currency(BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB)
         "system": "BitCoin", // system(BitCoin, Ethereum, Litecoin, Dogecoin, Dash, BitcoinCash, TON, Ripple, TRON, Stellar, BinanceCoin, TRON_TRC20, BinanceSmartChain_BEP20, Ethereum_ERC20)
         "address": "3LaKdUrPfVyZeEVYpZei3HwjqQj5AHHTCE", //Destination address
         "tag": "", //Tag for Ripple and Stellar
         "hash": "ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd", //uuid of payment link
         "partial": "no" // set up underpayments or overpayments 'yes' to accept, 'no' - do not take
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Account not found",
     "data": {}
}
SCI | Check transaction notification(for IPN)
Method name: sci_confirm_transaction_notification. This method should be called to get and check notification information for incoming transactions. The handler is called automatically by the PayKassa.pro service until the script responds <order_id>|success (maximum 5 times, send notification by manual not supported). The payment processor is called automatically from the notification servers 54.37.60.196, 51.91.80.241, 138.68.137.53. These IPs need to be added to the exceptions of your FireWall or DDoS filter, so that notifications go smoothly. The current list of IP can be obtained in text format via the URL: https://paykassa.pro/ips.txt or in JSON format: https://paykassa.pro/ips.php. The server sends a POST request, in which it passes a private_hash (random string), system (the name of the payment system or currency), currency (abbreviated currency name), order_id (payment id in your project). Next you must pass the received private_hash in the SCI request to the sci_confirm_transaction_notification method, which will allow you to check whether the payment was successful.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_confirm_transaction_notification

Default value: sci_confirm_transaction_notification

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

private_hash   String    
From POST request

test Boolean   
Must be false only

Default value: false

Allowed values: false

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  transaction  String    
Invoice ID in Paykassa

  txid    String    
Public transaction hash for track transfer

  shop_id String    
Merchant ID in Paykassa

  order_id     String    
Payment ID in your merchant

  amount  String    
Amount to be received

  fee     String    
Fee of network

  currency     String    
Name of currency

  system  String    
Name of system

  address_from String    
Source address if exist

  address String    
Destination address

  tag     String    
Tag for Ripple and Stellar

  confirmations     String    
Current count confirmations

  required_confirmations String    
Count confirmations for credited

  status  String    
"no" - not confirmed, "yes" - confirmed and credited

  static  String    
"yes" - yes only

  date_update  String    
Date last change transaction info

  explorer_address_link  String    
Link to address explorer

  explorer_transaction_link   String    
Link to transaction explorer

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Ok",
     "data": {
         "transaction": "2431038", // transaction number in the system paykassa: 96401
         "txid": "e2be8b51ad0ccbae2a2433f8c940035ce97903c7de1a1cefa1db40cc1cabb0e5", //Hash track for explorer
         "shop_id": "138",  // Merchant ID 123
         "order_id": "order 1", // unique numeric identifier of the payment in your merchant, example: 150800
         "amount": "1.00000000", //  amount to credited example: 1.01
         "fee": "0.00000000", //  fee of network
         "currency": "DOGE", // currency(USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB)
         "system": "Dogecoin", //system(BitCoin, Ethereum, Litecoin, Dogecoin, Dash, BitcoinCash, TON, Ripple, TRON, Stellar, BinanceCoin, TRON_TRC20, BinanceSmartChain_BEP20, Ethereum_ERC20)
         "address_from": "", //Not empty for: Ethereum, TON,  Ripple, Stellar, TRON, BinanceCoin, TRON_TRC20, BinanceSmartChain_BEP20, Ethereum_ERC20
         "address": "DKpzDZuFoTpPpnpsMro8NBtmDz8rinCjqp", //Target address
         "tag": "", //Tag for Ripple and Stellar
         "confirmations": 0, //Current count confirmations
         "required_confirmations": 3, //Count confirmations for credited
         "status": "no", //"no" - not confirmed, "yes" - confirmed and credited
         "static": "yes", //"yes" - yes only
         "date_update": "2020-07-23 15:06:58", //Date last change transaction info
         "explorer_address_link": "https://explorer.paykassa.pro/address/dogecoin-doge/DKpzDZuFoTpPpnpsMro8NBtmDz8rinCjqp", //Link to address explorer
         "explorer_transaction_link": "https://explorer.paykassa.pro/transaction/dogecoin-doge/e2be8b51ad0ccbae2a2433f8c940035ce97903c7de1a1cefa1db40cc1cabb0e5" //Link to transaction explorer
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Account not found",
     "data": {}
}
SCI | Get cryptocurrency address for deposit
Method name: sci_create_order_get_data. Creates an address to receive payment. After creating an address for payment, you need to display it on your project page along with a small instruction on how to pay.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_create_order_get_data

Default value: sci_create_order_get_data

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

order_id  String    
Payment ID in your merchant

amount    String    
Amount to be received

currency  String    
Currency to be received

Allowed values: BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB

system    Number    
ID of system must match currency

Allowed values: 11-BitCoin(BTC), 12-Ethereum(ETH), 14-Litecoin(LTC), 15-Dogecoin(DOGE), 16-Dash(DASH), 18-BitcoinCash(BCH), 33-TON(TON, USDT), 22-Ripple(XRP), 27-TRON(TRX), 28-Stellar(XLM), 29-BinanceCoin(BNB), 30-TRON_TRC20(USDT), 31-BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), 32-Ethereum_ERC20(USDT, USDC, SHIB)

comment   String    
Comments for history

test Boolean   
Turn on test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  invoice String    
Invoice ID in Paykassa

  order_id     String    
Payment ID in your merchant

  wallet  String    
Destination address

  amount  String    
Amount to be received

  system  String    
Name of system

  currency     String    
Name of currency

  url     String    
URL to redirect user for paying process

  tag     String    
Optional if not false, you must pass he payeer

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Data has been successfully received.",
     "data": {
         "invoice": "579205",
         "order_id": "12345",
         "wallet": "3LaKdUrPfVyZeEVYpZei3HwjqQj5AHHTCE", // Wallet to pay
         "amount": "1.03030000",
         "system": "BitCoin",
         "currency": "BTC",
         "url": "https://crypto.paykassa.pro/sci/index.php?hash=ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd", # link to redirect
         "tag": false // not false if exists
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Specify the payment amount. Error code: 22",
     "data": {}
}
SCI | Get link for deposit
Method name: sci_create_order. Creates a link to payment. After creating the link, you need to redirect to it for further payment.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_create_order

Default value: sci_create_order

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

order_id  String    
Payment ID in your merchant

amount    String    
Amount to be received

currency  String    
Currency to be received

Allowed values: BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB

system    Number    
ID of system must match currency

Allowed values: 11-BitCoin(BTC), 12-Ethereum(ETH), 14-Litecoin(LTC), 15-Dogecoin(DOGE), 16-Dash(DASH), 18-BitcoinCash(BCH), 33-TON(TON, USDT), 22-Ripple(XRP), 27-TRON(TRX), 28-Stellar(XLM), 29-BinanceCoin(BNB), 30-TRON_TRC20(USDT), 31-BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), 32-Ethereum_ERC20(USDT, USDC, SHIB)

comment   String    
Comments for history

test String    
Turn on test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  url     String    
URL to create the payment form

  method  String    
Method to create the payment form

  params  String    
Params to create the payment form

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Data has been successfully received.",
     "data": {
         "url": "https://crypto.paykassa.pro/sci/index.php?hash=ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd", # link to redirect
         "method": "GET",
         "params": {
             "hash": "ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd"
         },
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Success-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Specify the payment amount. Error code: 22",
     "data": {}
}


SCI | Check payment(for IPN)
Method name: sci_confirm_order. This method is used in the handler of the payment receipt. The handler is called automatically by the PayKassa.pro service until the script responds <order_id>|success (maximum 5 times, otherwise you need to send a notification manually from the profile). The payment processor is called automatically from the notification servers 54.37.60.196, 51.91.80.241, 138.68.137.53. These IPs need to be added to the exceptions of your FireWall or DDoS filter, so that notifications go smoothly. The current list of IP can be obtained in text format via the URL: https://paykassa.pro/ips.txt or in JSON format: https://paykassa.pro/ips.php. The server sends a POST request, in which it passes a private_hash (random string), system (the name of the payment system or currency), currency (abbreviated currency name), order_id (payment id in your project). Next you must pass the received private_hash in the SCI request to the sci_confirm_order method, which will allow you to check whether the payment was successful.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_confirm_order

Default value: sci_confirm_order

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

private_hash   String    
From POST request

test Boolean   
Turn on test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  transaction  String    
Invoice ID in Paykassa

  shop_id String    
Merchant ID in Paykassa

  order_id     String    
Payment ID in your merchant

  amount  String    
Amount to be received

  currency     String    
Name of currency

  system  String    
Name of system

  address String    
Destination address

  tag     String    
Tag for Ripple and Stellar

  hash    String    
Uuid of payment link

  partial String    
Arbitrary amount payment identifier

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Payment successfully verified",
     "data": {
         "transaction": "96401", // transaction number in the system paykassa: 96401
         "shop_id": "123", // Merchant ID 123
         "order_id": "12345",  // unique numeric identifier of the payment in your merchant, example: 150800
         "amount": "1.01", // invoice amount example: 1.01
         "currency": "BTC", // currency(BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB)
         "system": "BitCoin", // system(BitCoin, Ethereum, Litecoin, Dogecoin, Dash, BitcoinCash, TON, Ripple, TRON, Stellar, BinanceCoin, TRON_TRC20, BinanceSmartChain_BEP20, Ethereum_ERC20)
         "address": "3LaKdUrPfVyZeEVYpZei3HwjqQj5AHHTCE", //Destination address
         "tag": "", //Tag for Ripple and Stellar
         "hash": "ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd", //uuid of payment link
         "partial": "no" // set up underpayments or overpayments 'yes' to accept, 'no' - do not take
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Account not found",
     "data": {}
}


SCI | Check transaction notification(for IPN)
Method name: sci_confirm_transaction_notification. This method should be called to get and check notification information for incoming transactions. The handler is called automatically by the PayKassa.pro service until the script responds <order_id>|success (maximum 5 times, send notification by manual not supported). The payment processor is called automatically from the notification servers 54.37.60.196, 51.91.80.241, 138.68.137.53. These IPs need to be added to the exceptions of your FireWall or DDoS filter, so that notifications go smoothly. The current list of IP can be obtained in text format via the URL: https://paykassa.pro/ips.txt or in JSON format: https://paykassa.pro/ips.php. The server sends a POST request, in which it passes a private_hash (random string), system (the name of the payment system or currency), currency (abbreviated currency name), order_id (payment id in your project). Next you must pass the received private_hash in the SCI request to the sci_confirm_transaction_notification method, which will allow you to check whether the payment was successful.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_confirm_transaction_notification

Default value: sci_confirm_transaction_notification

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

private_hash   String    
From POST request

test Boolean   
Must be false only

Default value: false

Allowed values: false

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  transaction  String    
Invoice ID in Paykassa

  txid    String    
Public transaction hash for track transfer

  shop_id String    
Merchant ID in Paykassa

  order_id     String    
Payment ID in your merchant

  amount  String    
Amount to be received

  fee     String    
Fee of network

  currency     String    
Name of currency

  system  String    
Name of system

  address_from String    
Source address if exist

  address String    
Destination address

  tag     String    
Tag for Ripple and Stellar

  confirmations     String    
Current count confirmations

  required_confirmations String    
Count confirmations for credited

  status  String    
"no" - not confirmed, "yes" - confirmed and credited

  static  String    
"yes" - yes only

  date_update  String    
Date last change transaction info

  explorer_address_link  String    
Link to address explorer

  explorer_transaction_link   String    
Link to transaction explorer

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Ok",
     "data": {
         "transaction": "2431038", // transaction number in the system paykassa: 96401
         "txid": "e2be8b51ad0ccbae2a2433f8c940035ce97903c7de1a1cefa1db40cc1cabb0e5", //Hash track for explorer
         "shop_id": "138",  // Merchant ID 123
         "order_id": "order 1", // unique numeric identifier of the payment in your merchant, example: 150800
         "amount": "1.00000000", //  amount to credited example: 1.01
         "fee": "0.00000000", //  fee of network
         "currency": "DOGE", // currency(USD, RUB, BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB)
         "system": "Dogecoin", //system(BitCoin, Ethereum, Litecoin, Dogecoin, Dash, BitcoinCash, TON, Ripple, TRON, Stellar, BinanceCoin, TRON_TRC20, BinanceSmartChain_BEP20, Ethereum_ERC20)
         "address_from": "", //Not empty for: Ethereum, TON,  Ripple, Stellar, TRON, BinanceCoin, TRON_TRC20, BinanceSmartChain_BEP20, Ethereum_ERC20
         "address": "DKpzDZuFoTpPpnpsMro8NBtmDz8rinCjqp", //Target address
         "tag": "", //Tag for Ripple and Stellar
         "confirmations": 0, //Current count confirmations
         "required_confirmations": 3, //Count confirmations for credited
         "status": "no", //"no" - not confirmed, "yes" - confirmed and credited
         "static": "yes", //"yes" - yes only
         "date_update": "2020-07-23 15:06:58", //Date last change transaction info
         "explorer_address_link": "https://explorer.paykassa.pro/address/dogecoin-doge/DKpzDZuFoTpPpnpsMro8NBtmDz8rinCjqp", //Link to address explorer
         "explorer_transaction_link": "https://explorer.paykassa.pro/transaction/dogecoin-doge/e2be8b51ad0ccbae2a2433f8c940035ce97903c7de1a1cefa1db40cc1cabb0e5" //Link to transaction explorer
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Account not found",
     "data": {}
}



SCI | Get cryptocurrency address for deposit
Method name: sci_create_order_get_data. Creates an address to receive payment. After creating an address for payment, you need to display it on your project page along with a small instruction on how to pay.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_create_order_get_data

Default value: sci_create_order_get_data

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

order_id  String    
Payment ID in your merchant

amount    String    
Amount to be received

currency  String    
Currency to be received

Allowed values: BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB

system    Number    
ID of system must match currency

Allowed values: 11-BitCoin(BTC), 12-Ethereum(ETH), 14-Litecoin(LTC), 15-Dogecoin(DOGE), 16-Dash(DASH), 18-BitcoinCash(BCH), 33-TON(TON, USDT), 22-Ripple(XRP), 27-TRON(TRX), 28-Stellar(XLM), 29-BinanceCoin(BNB), 30-TRON_TRC20(USDT), 31-BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), 32-Ethereum_ERC20(USDT, USDC, SHIB)

comment   String    
Comments for history

test Boolean   
Turn on test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  invoice String    
Invoice ID in Paykassa

  order_id     String    
Payment ID in your merchant

  wallet  String    
Destination address

  amount  String    
Amount to be received

  system  String    
Name of system

  currency     String    
Name of currency

  url     String    
URL to redirect user for paying process

  tag     String    
Optional if not false, you must pass he payeer

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Data has been successfully received.",
     "data": {
         "invoice": "579205",
         "order_id": "12345",
         "wallet": "3LaKdUrPfVyZeEVYpZei3HwjqQj5AHHTCE", // Wallet to pay
         "amount": "1.03030000",
         "system": "BitCoin",
         "currency": "BTC",
         "url": "https://crypto.paykassa.pro/sci/index.php?hash=ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd", # link to redirect
         "tag": false // not false if exists
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Error-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Specify the payment amount. Error code: 22",
     "data": {}
}


SCI | Get link for deposit
Method name: sci_create_order. Creates a link to payment. After creating the link, you need to redirect to it for further payment.

POST
https://paykassa.app/sci/0.4/index.php
Parameter
Field     Type Description
func String    
Method name, must be: sci_create_order

Default value: sci_create_order

sci_id    String    
Merchant ID

sci_key   String    
Merchant Password

order_id  String    
Payment ID in your merchant

amount    String    
Amount to be received

currency  String    
Currency to be received

Allowed values: BTC, ETH, LTC, DOGE, DASH, BCH, TON, XRP, TRX, XLM, BNB, USDT, USDC, ADA, EOS, SHIB

system    Number    
ID of system must match currency

Allowed values: 11-BitCoin(BTC), 12-Ethereum(ETH), 14-Litecoin(LTC), 15-Dogecoin(DOGE), 16-Dash(DASH), 18-BitcoinCash(BCH), 33-TON(TON, USDT), 22-Ripple(XRP), 27-TRON(TRX), 28-Stellar(XLM), 29-BinanceCoin(BNB), 30-TRON_TRC20(USDT), 31-BinanceSmartChain_BEP20(USDT, USDC, ADA, EOS, BTC, ETH, DOGE, SHIB), 32-Ethereum_ERC20(USDT, USDC, SHIB)

comment   String    
Comments for history

test String    
Turn on test mode

Default value: false

Allowed values: false, true

Success 200
Field     Type Description
error     Boolean   
false - Success

Information    String    
message

data Object    
Extradata

  url     String    
URL to create the payment form

  method  String    
Method to create the payment form

  params  String    
Params to create the payment form

Success-Response:
HTTP/1.1 200 OK
{
     "error": false,
     "message": "Data has been successfully received.",
     "data": {
         "url": "https://crypto.paykassa.pro/sci/index.php?hash=ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd", # link to redirect
         "method": "GET",
         "params": {
             "hash": "ba276492c1c8ff5bfad7ea46463aca85d9c447ee940aceeb71e4a726d89458cd"
         },
     }
}
Error 4xx
Name Type Description
error     Boolean   
true - Fail

message   String    
Error description

data Object    
Empty

Success-Response:
HTTP/1.1 200 OK
{
     "error": true,
     "message": "Specify the payment amount. Error code: 22",
     "data": {}
}



Paykassa payment gateway API
API Paykassa is a universal solution for working with online payments in cryptocurrencies.

IP address of the notification server for SCI: 138.68.137.53, 165.232.140.156, 2604:a880:4:1d0::1d1:d000. The current IP list can be obtained in text format by URL: https://paykassa.pro/ips.txt, JSON: https://paykassa.pro/ips.php

Documentation.
Check out the Paykassa connection documentation.

Detailed documentation
PHP classes
Download and connect PHP classes to accept payments and payments.

SCI classes for Accept payments
API classes for payments

A quick start for lazy PHP programmers
# Get a reusable address to pay with cryptocurrency (Step 1)
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaSCI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    


    $params = [
        "amount" => null,
        "system" => "TRON_TRC20",
        "currency" => "USDT",
        "order_id" => "My order id "  . microtime(true),
        "comment" => "My comment",
    ];

    $paykassa = new \Paykassa\PaykassaSCI(
        $secret_keys_and_config["merchant_id"],
        $secret_keys_and_config["merchant_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );


    $res = $paykassa->createAddress(
        $params["system"],
        $params["currency"],
        $params["order_id"],
        $params["comment"]
    );

    if ($res['error']) {
        echo $res['message'];
        // actions in case of an error
    } else {
        if (false === $secret_keys_and_config["config"]["test_mode"]) {
            $invoice_id = $res['data']['invoice'];

            $address = $res["data"]["wallet"];
            $tag = $res["data"]["tag"];
            $tag_name = $res["data"]["tag_name"];
            $is_tag = $res["data"]["is_tag"];

            $system = $res["data"]["system"];
            $currency = $res["data"]["currency"];

            $display = sprintf("address %s", $address);
            if ($is_tag) {
                $display = sprintf("address %s %s: %s", $address, mb_convert_case($tag_name, MB_CASE_TITLE), $tag);
            }

            if (null === $params["amount"]) {
                echo sprintf(
                    "Send money to the %s %s %s.",
                    $system,
                    $currency,
                    htmlspecialchars($display,ENT_QUOTES, "UTF-8")
                );
            } else {
                echo sprintf(
                    "Send %s %s to the %s %s.",
                    $params["amount"],
                    $currency,
                    $system,
                    htmlspecialchars($display, ENT_QUOTES, "UTF-8")
                );
            }


            //Creating QR
            $qr_request = $paykassa->getQrLink($res['data'], $params["amount"]);
            if (!$qr_request["error"]) {
                echo sprintf(
                    '<br><br>QR Code:<br><img alt="" src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=%s">',
                    $qr_request["data"]["link"]
                );
            }
        } else {
            echo sprintf('Test link: <a target="_blank" href="%s">Open link</a>', $res["data"]["url"]);
        }
    }

            
Deploy 
# Receive and process an IPN notification of an incoming transaction (Step 2)
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaSCI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    




    $paykassa = new \Paykassa\PaykassaSCI(
        $secret_keys_and_config["merchant_id"],
        $secret_keys_and_config["merchant_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );

    $private_hash = $_POST["private_hash"];

    $res = $paykassa->checkTransactionIpn(
        $private_hash
    );

    if ($res['error']) {
        echo $res['message'];
        // actions in case of an error
    } else {
        // actions in case of success
        $transaction = $res["data"]["transaction"];         // transaction number in the system paykassa: 2431548
        $txid = $res["data"]["txid"];                       // A transaction in a cryptocurrency network, an example: 0xb97189db3555015c46f2805a43ed3d700a706b42fb9b00506fbe6d086416b602
        $shop_id = $res["data"]["shop_id"];                 // Your merchant's number, example: 138
        $id = $res["data"]["order_id"];                     // unique numeric identifier of the payment in your system, example: 150800
        $amount = $res["data"]["amount"];            // received amount, example: 1.0000000
        $fee = $res["data"]["fee"];                  // Payment processing commission: 0.0000000
        $currency = $res["data"]["currency"];               // the currency of payment, for example: DASH
        $system = $res["data"]["system"];                   // system, example: Dash
        $address_from = $res["data"]["address_from"];       // address of the payer's cryptocurrency wallet, example: 0x5d9fe07813a260857cf60639dac710ebb9531a20
        $address = $res["data"]["address"];                 // a cryptocurrency wallet address, for example: Xybb9RNvdMx8vq7z24srfr1FQCAFbFGWLg
        $tag = $res["data"]["tag"];                         // Tag for Ripple and Stellar is an integer
        $confirmations = $res["data"]["confirmations"];     // Current number of network confirmations
        $required_confirmations =
            $res["data"]["required_confirmations"];         // Required number of network confirmations for crediting
        $status = $res["data"]["status"];                   // yes - if the payment is credited
        $static = $res["data"]["static"];                   // Always yes
        $date_update = $res["data"]["date_update"];         // last updated information, example: "2018-07-23 16:03:08"

        $explorer_address_link =
            $res["data"]["explorer_address_link"];          // A link to view information about the address
        $explorer_transaction_link =
            $res["data"]["explorer_transaction_link"];      // Link to view transaction information


        if ($status !== 'yes') {
            //the payment has not been credited yet
            // your code...


            echo $id.'|success'; // confirm receipt of the request
        } else {
            //the payment is credited
            // your code...

            echo $id.'|success'; // be sure to confirm the payment has been received

        }
    }

            
Deploy 
# Make a payment (transfer of funds) (Step 3)
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaAPI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    


    $params = [
        "merchant_id" => $secret_keys_and_config["merchant_id"],
        "wallet" => [
            "address" => "TTEAUAzhSFomrv9P7Q5AcqTchWHBq745gh",
            "tag" => "",
        ],
        "amount" => "5.123456",
        "system" => "TRON_TRC20",
        "currency" => "USDT",
        "comment" => "My comment",
        "priority" => "medium", // low, medium, high
    ];


    $paykassa = new \Paykassa\PaykassaAPI(
        $secret_keys_and_config["api_id"],
        $secret_keys_and_config["api_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );


    $res = $paykassa->sendMoney(
        $params["merchant_id"],
        $params["wallet"],
        $params["amount"],
        $params["system"],
        $params["currency"],
        $params["comment"],
        $params["priority"]
    );
    
    if ($res["error"]) {        // $res["error"] - true if the error
        echo $res["message"];   // $res["message"] - the text of the error message
        //actions in case of an error
    } else {
        //actions in case of success
        $merchant_id = $res["data"]["shop_id"];                     // merchant id that you originally made payment, example 122
        $transaction = $res["data"]["transaction"];                 // transaction number of the payment, example 130236
        $txid = $res["data"]["txid"];                               // txid 70d6dc6841782c6efd8deac4b44d9cc3338fda7af38043dd47d7cbad7e84d5dd can be empty
        // In this case, the information about the transaction can be obtained using a universal link from the Explorer_Transaction_Link field, see below
        $payment_id = $res["data"]["payment_id"];                   // Payment transaction number in the payment system, example 478937139
        $amount = $res["data"]["amount"];                           // the amount of the payment, how much was written off from the balance of the merchant 0.42
        $amount_pay = $res["data"]["amount_pay"];                   // the amount of the payment, as it is the user, example: 0.41
        $system = $res["data"]["system"];                           // the system of payment, which was made the payment, example: Bitcoin
        $currency = $res["data"]["currency"];                       // the payment currency, for example: BTC
        $number = $res["data"]["number"];                           // the address where you sent the funds
        $commission_percent = $res["data"]["shop_commission_percent"];// the transfer fee percentage, example: 1.5
        $commission_amount = $res["data"]["shop_commission_amount"];  // the transfer fee amount, example: 1.00
        $paid_commission = $res["data"]["paid_commission"];         // who paid for the Commission, for example: shop
    
    
        $explorer_address_link =
            $res["data"]["explorer_address_link"];          // A link to view information about the address
        $explorer_transaction_link =
            $res["data"]["explorer_transaction_link"];      // Link to view transaction information


        echo sprintf(
            'We have sent the %s %s %s to <a target="_blank" href="%s">%s</a>. The txid is <a target="_blank" href="%s">%s</a>',
            $system,
            $amount,
            $currency,
            $explorer_address_link,
            $number,
            $explorer_transaction_link,
            $txid
        );
    }

            
Deploy 
# Get Txid Payments (Step 4)
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaAPI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    

    $params = [
        "merchant_id" => $secret_keys_and_config["merchant_id"],
    ];


    $paykassa = new \Paykassa\PaykassaAPI(
        $secret_keys_and_config["api_id"],
        $secret_keys_and_config["api_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );

    $invice_ids = [
        "37411867",
        "37411866",
        "37411863",
    ];

    $res = $paykassa->getTxIdsByInvoiceIds(
        $params["merchant_id"],
        $invice_ids
    );
    
    if ($res["error"]) {        // $res["error"] - true if the error
        echo $res["message"];   // $res["message"] - the text of the error message
        //actions in case of an error
    } else {
        ?><ul><?php
        foreach ($invice_ids as $invoice_id) {
            //IMPORTANT!!!!
            if (!isset($res["data"][$invoice_id])) {
                continue;
            }
            $txids = $res["data"][$invoice_id];
            ?><li><?php
            echo sprintf("Invoice ID: %s<br>", $invoice_id);
            foreach ($txids as $txid) {
                echo sprintf("TXID: %s<br>", $txid);
            }
            ?></li><?php
        }
        ?></ul><?php
    }

            
Deploy 
# Own payment page
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaSCI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    

    $paykassa = new \Paykassa\PaykassaSCI(
        $secret_keys_and_config["merchant_id"],
        $secret_keys_and_config["merchant_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );

    if ("GET" === $_SERVER['REQUEST_METHOD']) {
        $list = \Paykassa\PaykassaSCI::getPaymentSystems("crypto");
?>
        <form action="" method="POST">
            <label>Select payment direction</label>
            <select name="pscur">
                <option value="">---</option>
                <?php foreach ($list as $item) { ?>
                    <?php foreach ($item["currency_list"] as $currency) { ?>
                        <option value="<?php echo htmlspecialchars(
                            sprintf("%s_%s", mb_strtolower($item["system"]), mb_strtolower($currency)),
                            ENT_QUOTES, "UTF-8"); ?>">
                            <?php echo htmlspecialchars(sprintf("%s %s", $item["display_name"], $currency),
                                ENT_QUOTES, "UTF-8"); ?>
                        </option>
                    <?php } ?>
                <?php } ?>
            </select>

            <button>To pay</button>
        </form>

<?php
        exit(0);
    }

    @list($system, $currency) = preg_split('~_(?=[^_]*$)~', $_POST["pscur"]);

    $params = [
        "amount" => null,
        "system" => $system,
        "currency" => $currency,
        "order_id" => "My order id "  . microtime(true),
        "comment" => "My comment",
    ];

    $res = $paykassa->createAddress(
        $params["system"],
        $params["currency"],
        $params["order_id"],
        $params["comment"]
    );

    if ($res['error']) {
        echo $res['message'];
        // actions in case of an error
    } else {
        if (false === $secret_keys_and_config["config"]["test_mode"]) {
            $invoice_id = $res['data']['invoice'];

            $address = $res["data"]["wallet"];
            $tag = $res["data"]["tag"];
            $tag_name = $res["data"]["tag_name"];
            $is_tag = $res["data"]["is_tag"];

            $system = $res["data"]["system"];
            $currency = $res["data"]["currency"];

            $display = sprintf("address %s", $address);
            if ($is_tag) {
                $display = sprintf("address %s %s: %s", $address, mb_convert_case($tag_name, MB_CASE_TITLE), $tag);
            }

            if (null === $params["amount"]) {
                echo sprintf(
                    "Send money to the %s %s %s.",
                    $system,
                    $currency,
                    htmlspecialchars($display,ENT_QUOTES, "UTF-8")
                );
            } else {
                echo sprintf(
                    "Send %s %s to the %s %s.",
                    $params["amount"],
                    $currency,
                    $system,
                    htmlspecialchars($display, ENT_QUOTES, "UTF-8")
                );
            }


            //Creating QR
            $qr_request = $paykassa->getQrLink($res['data'], $params["amount"]);
            if (!$qr_request["error"]) {
                echo sprintf(
                    '<br><br>QR Code:<br><img alt="" src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=%s">',
                    $qr_request["data"]["link"]
                );
            }
        } else {
            echo sprintf('Test link: <a target="_blank" href="%s">Open link</a>', $res["data"]["url"]);
        }
    }

            
Deploy 
# Create a payment link
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaSCI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    


    $params = [
        "amount" => "100.00",
        "system" => "BitCoin",
        "currency" => "BTC",
        "order_id" => "My order id "  . microtime(true),
        "comment" => "My comment",
    ];


    $paykassa = new \Paykassa\PaykassaSCI(
        $secret_keys_and_config["merchant_id"],
        $secret_keys_and_config["merchant_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );


    $res = $paykassa->createOrder(
        $params["amount"],
        $params["system"],
        $params["currency"],
        $params["order_id"],
        $params["comment"]
    );

    if ($res['error']) {
        echo $res['message'];
        // actions in case of an error
    } else {
        if (false === $secret_keys_and_config["config"]["test_mode"]) {
            ?>
            Click the button to make the payment
            <form action="<?php echo $res["data"]["url"]; ?>" method="POST">
                <button>To pay</button>
            </form>
<?php
        } else {
            echo sprintf('Test link: <a target="_blank" href="%s">Open link</a>', $res["data"]["url"]);
        }
    }

            
Deploy 
# Process IPN payment invoice (old universal way)
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaSCI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    




    $paykassa = new \Paykassa\PaykassaSCI(
        $secret_keys_and_config["merchant_id"],
        $secret_keys_and_config["merchant_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );

    $private_hash = $_POST["private_hash"];

    $res = $paykassa->checkOrderIpn(
        $private_hash
    );

    if ($res['error']) {
        echo $res['message'];
        // actions in case of an error
    } else {
        // actions in case of success
        $id = $res["data"]["order_id"];        // unique numeric identifier of the payment in your system, example: 150800
        $transaction = $res["data"]["transaction"]; // transaction number in the system paykassa: 96401
        $hash = $res["data"]["hash"];               // hash, example: bde834a2f48143f733fcc9684e4ae0212b370d015cf6d3f769c9bc695ab078d1
        $currency = $res["data"]["currency"];       // the currency of payment, for example: DASH
        $system = $res["data"]["system"];           // system, example: Dash
        $address = $res["data"]["address"];         // a cryptocurrency wallet address, for example: Xybb9RNvdMx8vq7z24srfr1FQCAFbFGWLg
        $tag = $res["data"]["tag"];                 // Tag for Ripple and Stellar
        $partial = $res["data"]["partial"];         // set up underpayments or overpayments 'yes' to accept, 'no' - do not take
        $amount = $res["data"]["amount"];    // invoice amount example: 1.0000000

        if ($partial === 'yes') {
            // the amount of application may differ from the amount received, if the mode of partial payment
            // relevant only for cryptocurrencies, default is 'no'
        }

        // your code...

        echo $id.'|success'; // be sure to confirm the payment has been received
    }

            
Deploy 
# Get the Merchant Balance
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaAPI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    

    $params = [
        "merchant_id" => $secret_keys_and_config["merchant_id"],
    ];


    $paykassa = new \Paykassa\PaykassaAPI(
        $secret_keys_and_config["api_id"],
        $secret_keys_and_config["api_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );


    $res = $paykassa->getMerchantBalances(
        $params["merchant_id"]
    );



    
    if ($res["error"]) {        // $res["error"] - true if the error
        echo $res["message"];   // $res["message"] - the text of the error message
        //actions in case of an error
    } else {

            $system = "Ethereum_ERC20";
            $currency = "USDT";

            $label = mb_strtolower(sprintf("%s_%s", $system, $currency));

            $data = $res["data"];

            echo sprintf(
                "Balance for %s %s %s",
                $system,
                $data[$label] ?? "0.0",
                $currency
            );
    }

            
Deploy 
# Get a payment history
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaAPI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    

    $params = [
        "type" => "pay_in", //pay_in, pay_out
        "shop_id" => $secret_keys_and_config["merchant_id"],
        "page_num" => 0,
        "status" => "yes", //yes - success, no - waiting or unsuccessful
        "datetime_start" => "2022-12-08T19:58:00+0000", //ISO 8601
        "datetime_end" => '2023-01-12T19:58:00+0000', //ISO 8601 - date("c", time())
    ];


    $paykassa = new \Paykassa\PaykassaAPI(
        $secret_keys_and_config["api_id"],
        $secret_keys_and_config["api_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );


    $res = $paykassa->getHistory(
        $params
    );
    $index = 1;
    do {
        if ($res["error"]) {        // $res["error"] - true if the error
            echo $res["message"];   // $res["message"] - the text of the error message
            //actions in case of an error
            break;
        } else {
            foreach ($res["data"]["list"] as $item) {
                echo sprintf("<b>Index - %d, Page - %d Total page - %d</b><br>", $index, $params["page_num"] + 1, $res["data"]["page_count"]);
                print_r($item);
                echo "<br>";
                $index += 1;
            }
        }
        $params["page_num"] += 1;
    } while ($params["page_num"] < $res["data"]["page_count"]);

            
Deploy 
# Get information about Merchant
Open an example code on GitHub

                
<?php

    require_once __DIR__ . "/PaykassaAPI.php";
    


    $secret_keys_and_config = [
        "merchant_id" => "Merchant ID",
        "merchant_password" => "Merchant Password",
        "api_id" => "API ID",
        "api_password" => "API Password",
        "config" => [
            "test_mode" => false,
        ],
    ];

    

    $params = [
        "merchant_id" => $secret_keys_and_config["merchant_id"],
    ];


    $paykassa = new \Paykassa\PaykassaAPI(
        $secret_keys_and_config["api_id"],
        $secret_keys_and_config["api_password"],
        $secret_keys_and_config["config"]["test_mode"]
    );


    $res = $paykassa->getMerchantInfo(
        $params["merchant_id"]
    );
    
    if ($res["error"]) {        // $res["error"] - true if the error
        echo $res["message"];   // $res["message"] - the text of the error message
        //actions in case of an error
    } else {
        var_dump($res["data"]["info"]);
    }

            
Deploy 
# Get cryptocurrency exchange rates
Open an example code on GitHub

                
<?php
    require_once __DIR__ . "/PaykassaCurrency.php";
    


    $pairs = [
        "BTC_USD",
        "USDT_ETH",
        "XRP_ADA",
    ];


    $res = \Paykassa\PaykassaCurrency::getCurrencyPairs($pairs);

    if ($res["error"]) {
        die($res["message"]);
    } else {
        $map_pairs = [];
        array_map(function ($pairs) use (&$map_pairs) {
            foreach ($pairs as $pair => $value) {
                $map_pairs[$pair] = $value;
            }
        }, $res["data"]);

        foreach ($map_pairs as $pair => $rate) {
            echo sprintf("Pairs - %s -> %s<br>", $pair, $rate);
        }

        $my_pair = "BTC_USD";
        echo sprintf("Request %s -> %s<br>", $my_pair, $map_pairs[$my_pair]);
    }

            
Deploy 
# Get the codes of all available currencies
Open an example code on GitHub

                
<?php
    require_once __DIR__ . "/PaykassaCurrency.php";
    

    $res = \Paykassa\PaykassaCurrency::getAvailableCurrencies();

    if ($res["error"]) {
        die($res["message"]);
    } else {
        print_r($res["data"]);
    }

            
Deploy 